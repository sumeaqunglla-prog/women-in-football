import React, { useEffect, useState } from 'react';
import { CheckCircle2, Trash2 } from 'lucide-react';

const STORIES_STORAGE_KEY = 'wif_community_stories_v1';

interface SubmittedStory {
  id: string;
  name: string;
  experience: string;
  inspiration: string;
  message: string;
  createdAt: string;
}

interface FormErrors {
  name?: string;
  experience?: string;
  inspiration?: string;
  message?: string;
}

export const StoryForm: React.FC = () => {
  const [name, setName] = useState('');
  const [experience, setExperience] = useState('');
  const [inspiration, setInspiration] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [stories, setStories] = useState<SubmittedStory[]>([]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORIES_STORAGE_KEY);
      if (saved) {
        setStories(JSON.parse(saved) as SubmittedStory[]);
      }
    } catch {
      // Ignore storage errors
    }
  }, []);

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (name.trim().length < 2) {
      nextErrors.name = 'Please enter your name (at least 2 characters).';
    }
    if (!experience.trim()) {
      nextErrors.experience = 'Please describe your connection or experience with football.';
    }
    if (inspiration.trim().length < 2) {
      nextErrors.inspiration = 'Please share who or what inspired you.';
    }
    if (message.trim().length < 10) {
      nextErrors.message = 'Please write a message of at least 10 characters for young girls.';
    }
    return nextErrors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmittedSuccess(false);
      return;
    }

    const newEntry: SubmittedStory = {
      id: `${Date.now()}`,
      name: name.trim(),
      experience: experience.trim(),
      inspiration: inspiration.trim(),
      message: message.trim(),
      createdAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    };

    const updated = [newEntry, ...stories];
    setStories(updated);
    try {
      localStorage.setItem(STORIES_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // Ignore storage write errors
    }

    setName('');
    setExperience('');
    setInspiration('');
    setMessage('');
    setErrors({});
    setSubmittedSuccess(true);
  };

  const handleClearStories = () => {
    setStories([]);
    try {
      localStorage.removeItem(STORIES_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
  };

  return (
    <div className="bg-[#FFFFFF] border border-[#641E2B]/15 p-6 sm:p-10">
      <div className="pb-6 mb-6 border-b hairline-cream">
        <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-2">
          Share Your Story
        </p>
        <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717]">
          Add Your Voice to the Pitch
        </h3>
        <p className="text-sm text-[#171717]/75 mt-2">
          Whether you play Sunday league, coach youth players, or cheer from the stands, leave an
          encouraging message for girls stepping onto the pitch today.
        </p>
      </div>

      {submittedSuccess && (
        <div
          role="status"
          className="mb-6 p-4 bg-[#14532D]/10 border border-[#14532D]/30 text-[#14532D] flex items-start gap-3"
        >
          <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" aria-hidden="true" />
          <div className="text-sm">
            <p className="font-semibold">Your story has been added to the local ledger.</p>
            <p className="text-xs mt-0.5">
              Saved locally in your browser via LocalStorage for this demonstration.
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label
              htmlFor="story-name"
              className="block text-xs uppercase tracking-wider font-semibold text-[#171717] mb-1.5"
            >
              Your Name
            </label>
            <input
              id="story-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Elena Morales"
              className="w-full px-3.5 py-2.5 text-sm bg-[#F5F0E8]/60 border border-[#641E2B]/25 text-[#171717] focus:outline-none focus:border-[#641E2B]"
            />
            {errors.name && <p className="text-xs text-[#641E2B] mt-1">{errors.name}</p>}
          </div>

          <div>
            <label
              htmlFor="story-experience"
              className="block text-xs uppercase tracking-wider font-semibold text-[#171717] mb-1.5"
            >
              Your Football Experience
            </label>
            <input
              id="story-experience"
              type="text"
              value={experience}
              onChange={(e) => setExperience(e.target.value)}
              placeholder="e.g., Amateur defender, youth coach, or lifelong fan"
              className="w-full px-3.5 py-2.5 text-sm bg-[#F5F0E8]/60 border border-[#641E2B]/25 text-[#171717] focus:outline-none focus:border-[#641E2B]"
            />
            {errors.experience && (
              <p className="text-xs text-[#641E2B] mt-1">{errors.experience}</p>
            )}
          </div>
        </div>

        <div>
          <label
            htmlFor="story-inspiration"
            className="block text-xs uppercase tracking-wider font-semibold text-[#171717] mb-1.5"
          >
            Your Biggest Inspiration
          </label>
          <input
            id="story-inspiration"
            type="text"
            value={inspiration}
            onChange={(e) => setInspiration(e.target.value)}
            placeholder="e.g., Marta, my first grassroots coach, or my older sister"
            className="w-full px-3.5 py-2.5 text-sm bg-[#F5F0E8]/60 border border-[#641E2B]/25 text-[#171717] focus:outline-none focus:border-[#641E2B]"
          />
          {errors.inspiration && (
            <p className="text-xs text-[#641E2B] mt-1">{errors.inspiration}</p>
          )}
        </div>

        <div>
          <label
            htmlFor="story-message"
            className="block text-xs uppercase tracking-wider font-semibold text-[#171717] mb-1.5"
          >
            Message for Young Girls Who Want to Play Football
          </label>
          <textarea
            id="story-message"
            rows={4}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Share a piece of advice or encouragement for the next generation..."
            className="w-full px-3.5 py-2.5 text-sm bg-[#F5F0E8]/60 border border-[#641E2B]/25 text-[#171717] focus:outline-none focus:border-[#641E2B]"
          />
          {errors.message && <p className="text-xs text-[#641E2B] mt-1">{errors.message}</p>}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <button
            type="submit"
            className="px-6 py-3 text-xs font-semibold uppercase tracking-wider bg-[#641E2B] text-[#FFFFFF] hover:bg-[#35121B] transition-colors cursor-pointer"
          >
            Submit Story
          </button>
          <p className="text-xs text-[#171717]/65">
            Stored locally in your browser (LocalStorage) for demonstration.
          </p>
        </div>
      </form>

      {/* Local Community Ledger */}
      {stories.length > 0 && (
        <div className="mt-8 pt-6 border-t hairline-cream">
          <div className="flex items-center justify-between mb-4">
            <p className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold">
              Your Submitted Stories ({stories.length})
            </p>
            <button
              type="button"
              onClick={handleClearStories}
              className="inline-flex items-center gap-1 text-xs text-[#171717]/65 hover:text-[#641E2B] cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Clear Local Stories</span>
            </button>
          </div>

          <div className="space-y-4">
            {stories.map((story) => (
              <article key={story.id} className="p-5 bg-[#F5F0E8]/70 border border-[#641E2B]/15">
                <div className="flex flex-wrap items-baseline justify-between gap-2 mb-2">
                  <h4 className="font-editorial text-xl font-semibold text-[#171717]">
                    {story.name}
                  </h4>
                  <span className="text-xs text-[#641E2B]">
                    {story.experience} · {story.createdAt}
                  </span>
                </div>
                <p className="text-xs text-[#171717]/75 mb-2">
                  Inspired by: <strong className="text-[#171717]">{story.inspiration}</strong>
                </p>
                <p className="text-sm leading-relaxed text-[#171717]/90 italic font-editorial">
                  “{story.message}”
                </p>
              </article>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
