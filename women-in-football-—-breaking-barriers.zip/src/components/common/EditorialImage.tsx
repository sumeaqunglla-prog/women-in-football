import React, { useState } from 'react';
import { ImageOff } from 'lucide-react';

interface EditorialImageProps {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  fallbackTitle?: string;
  priority?: boolean;
}

export const EditorialImage: React.FC<EditorialImageProps> = ({
  src,
  alt,
  className = '',
  imgClassName = 'w-full h-full object-cover',
  fallbackTitle,
  priority = false,
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`relative flex flex-col items-center justify-center bg-gradient-to-br from-[#35121B] via-[#641E2B] to-[#171717] text-[#F5F0E8] p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <ImageOff className="w-7 h-7 text-[#E7DED2]/70 mb-2" aria-hidden="true" />
        <p className="font-editorial text-lg font-medium tracking-wide">
          {fallbackTitle || 'Editorial Photograph'}
        </p>
        <p className="text-xs text-[#E7DED2]/70 max-w-xs mt-1">{alt}</p>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-[#35121B]/10 ${className}`}>
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        loading={priority ? 'eager' : 'lazy'}
        decoding={priority ? 'sync' : 'async'}
        onError={() => setHasError(true)}
        className={imgClassName}
      />
    </div>
  );
};
