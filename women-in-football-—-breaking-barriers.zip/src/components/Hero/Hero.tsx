import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, ArrowRight } from 'lucide-react';
import { EditorialImage } from '../common/EditorialImage';

interface HeroProps {
  onExploreStory: () => void;
  onDiscoverLegacy: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreStory, onDiscoverLegacy }) => {
  return (
    <section
      id="home"
      className="relative min-h-[100svh] w-full flex flex-col justify-end bg-[#171717] text-[#FFFFFF] overflow-hidden"
    >
      {/* Full-bleed Dramatic Stadium Photography */}
      <div className="absolute inset-0">
        <EditorialImage
          src="/src/assets/images/hero_stadium_players_1795104375233.jpg"
          alt="Female professional football players celebrating together under stadium floodlights before a roaring crowd"
          className="w-full h-full"
          imgClassName="w-full h-full object-cover object-center"
          fallbackTitle="Women in Football"
          priority
        />
        {/* Measured contrast scrims for WCAG AA/AAA readability */}
        <div
          className="absolute inset-0 bg-gradient-to-t from-[#171717] via-[#35121B]/65 to-[#171717]/40"
          aria-hidden="true"
        />
        <div
          className="absolute inset-0 bg-gradient-to-r from-[#171717]/80 via-[#35121B]/35 to-transparent"
          aria-hidden="true"
        />
      </div>

      {/* Editorial Foreground */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 sm:px-8 lg:px-12 pt-28 pb-12 sm:pb-16 lg:pb-20">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-4xl"
        >
          {/* Small publication-style metadata — unboxed text */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs tracking-[0.18em] uppercase text-[#E7DED2]/90 mb-6 font-medium">
            <span>Special Investigative Feature</span>
            <span aria-hidden="true">·</span>
            <span>Archival & Modern Edition</span>
            <span aria-hidden="true">·</span>
            <span>1881 – Present</span>
          </div>

          {/* Main Oversized Headline */}
          <h1 className="font-editorial text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-semibold leading-[0.95] tracking-[-0.02em] text-[#FFFFFF] mb-4">
            MORE THAN A GAME.
          </h1>

          {/* Secondary Headline */}
          <p className="font-editorial text-2xl sm:text-3xl md:text-4xl font-normal italic text-[#E7DED2] leading-[1.15] max-w-3xl mb-6">
            THE WOMEN WHO CHANGED FOOTBALL FOREVER.
          </p>

          {/* Hairline editorial rule */}
          <div className="w-24 h-px bg-[#E7DED2]/50 mb-6" aria-hidden="true" />

          {/* Supporting Manifesto Line */}
          <p className="text-base sm:text-lg text-[#F5F0E8]/90 max-w-2xl leading-relaxed mb-9 font-normal">
            Every generation has faced barriers. Every generation has found a way to break them.
            From banned factory pitches to 91,648 roaring fans under European floodlights, this is
            the story of how women reclaimed football.
          </p>

          {/* Two Editorial CTA Buttons */}
          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={onExploreStory}
              className="inline-flex items-center gap-2.5 px-7 py-3.5 text-sm font-semibold tracking-wider uppercase bg-[#F5F0E8] text-[#35121B] hover:bg-[#FFFFFF] transition-colors duration-150 cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FFFFFF]"
            >
              <span>Explore Their Story</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onDiscoverLegacy}
              className="inline-flex items-center gap-2.5 px-7 py-3.5 text-sm font-semibold tracking-wider uppercase border border-[#F5F0E8]/55 text-[#F5F0E8] hover:bg-[#641E2B]/80 hover:border-[#F5F0E8] transition-colors duration-150 cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E7DED2]"
            >
              <span>Discover Their Legacy</span>
            </button>
          </div>
        </motion.div>

        {/* Bottom Publication Deck + Scroll Indicator */}
        <div className="mt-12 pt-6 border-t border-[#F5F0E8]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-[#E7DED2]/80">
          <p className="max-w-xl leading-relaxed">
            “From fighting for the right to play to filling the world’s biggest stadiums, discover
            the women who challenged expectations and transformed the beautiful game.”
          </p>

          <button
            type="button"
            onClick={onExploreStory}
            className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-[#F5F0E8] hover:text-[#FFFFFF] self-start sm:self-auto cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E7DED2]"
          >
            <span>Scroll to Read</span>
            <ArrowDown className="w-3.5 h-3.5 animate-bounce" aria-hidden="true" />
          </button>
        </div>
      </div>
    </section>
  );
};
