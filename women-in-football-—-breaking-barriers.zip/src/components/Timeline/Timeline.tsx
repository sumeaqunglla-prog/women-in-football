import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import {
  TIMELINE_ERAS,
  TIMELINE_MILESTONES,
  TimelineEra,
} from '../../data/timelineData';
import { EditorialImage } from '../common/EditorialImage';

export const Timeline: React.FC = () => {
  const [selectedEra, setSelectedEra] = useState<TimelineEra>('all');
  const [activeId, setActiveId] = useState<string>(TIMELINE_MILESTONES[1].id);

  const filteredMilestones = useMemo(() => {
    if (selectedEra === 'all') return TIMELINE_MILESTONES;
    return TIMELINE_MILESTONES.filter((m) => m.era === selectedEra);
  }, [selectedEra]);

  const activeIndex = useMemo(() => {
    const idx = filteredMilestones.findIndex((m) => m.id === activeId);
    return idx >= 0 ? idx : 0;
  }, [filteredMilestones, activeId]);

  const activeMilestone = filteredMilestones[activeIndex] ?? TIMELINE_MILESTONES[0];

  const handleEraChange = (era: TimelineEra) => {
    setSelectedEra(era);
    const nextList =
      era === 'all'
        ? TIMELINE_MILESTONES
        : TIMELINE_MILESTONES.filter((m) => m.era === era);
    if (nextList.length > 0 && !nextList.some((m) => m.id === activeId)) {
      setActiveId(nextList[0].id);
    }
  };

  const handleStep = (direction: -1 | 1) => {
    const nextIdx = activeIndex + direction;
    if (nextIdx >= 0 && nextIdx < filteredMilestones.length) {
      setActiveId(filteredMilestones[nextIdx].id);
    }
  };

  return (
    <section
      id="breaking-barriers"
      className="bg-[#35121B] text-[#F5F0E8] py-20 sm:py-28 border-b hairline-dark"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header + Era Filter Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 pb-10 border-b hairline-dark">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-[0.2em] text-[#E7DED2]/80 font-semibold mb-3">
              Interactive Historical Chronology · 1895 – 2023
            </p>
            <h2 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#FFFFFF] leading-[1.06]">
              Breaking Barriers: A Century on the Pitch
            </h2>
            <p className="mt-4 text-base text-[#E7DED2]/85 leading-relaxed">
              Select any historical milestone along the timeline to examine how players defied
              institutional bans, built leagues, and filled the largest stadiums on earth.
            </p>
          </div>

          {/* Interactive Era Filter Tabs */}
          <div
            role="tablist"
            aria-label="Filter timeline by era"
            className="flex flex-wrap items-center gap-1.5 bg-[#171717]/40 p-1.5 border border-[#F5F0E8]/15"
          >
            {TIMELINE_ERAS.map((era) => {
              const isSelected = selectedEra === era.id;
              return (
                <button
                  key={era.id}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => handleEraChange(era.id)}
                  className={`px-3.5 py-2 text-xs font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E7DED2] ${
                    isSelected
                      ? 'bg-[#F5F0E8] text-[#35121B] font-semibold'
                      : 'text-[#E7DED2]/80 hover:text-[#FFFFFF] hover:bg-[#641E2B]/50'
                  }`}
                >
                  {era.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Horizontal Interactive Milestone Strip */}
        <div className="py-8 border-b hairline-dark overflow-x-auto">
          <div className="flex items-stretch gap-3 min-w-max">
            {filteredMilestones.map((item, idx) => {
              const isActive = item.id === activeMilestone.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveId(item.id)}
                  className={`text-left w-52 p-4 border transition-colors duration-150 cursor-pointer flex flex-col justify-between focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E7DED2] ${
                    isActive
                      ? 'bg-[#641E2B] border-[#F5F0E8]/70 text-[#FFFFFF]'
                      : 'bg-[#171717]/30 border-[#F5F0E8]/15 text-[#E7DED2]/80 hover:border-[#F5F0E8]/45 hover:text-[#FFFFFF]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="font-data text-lg font-medium text-[#FFFFFF]">
                      {item.year}
                    </span>
                    <span className="font-data text-[11px] text-[#E7DED2]/65">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                  </div>
                  <p className="font-editorial text-lg font-medium leading-snug line-clamp-2">
                    {item.title}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Milestone Spotlight Panel */}
        <div className="pt-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div
            className={`${
              activeMilestone.image ? 'lg:col-span-7' : 'lg:col-span-12'
            } flex flex-col justify-between bg-[#171717]/35 border border-[#F5F0E8]/15 p-7 sm:p-10`}
          >
            <div>
              <div className="flex flex-wrap items-center justify-between gap-4 pb-6 mb-6 border-b hairline-dark">
                <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.16em] text-[#E7DED2]/85">
                  <span className="font-semibold text-[#FFFFFF]">{activeMilestone.eraLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" aria-hidden="true" />
                    {activeMilestone.location}
                  </span>
                </div>

                <span className="font-data text-3xl sm:text-4xl font-medium text-[#F5F0E8]">
                  {activeMilestone.year}
                </span>
              </div>

              <h3 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#FFFFFF] leading-tight mb-5">
                {activeMilestone.title}
              </h3>

              <p className="text-base sm:text-lg leading-relaxed text-[#F5F0E8]/90 mb-6">
                {activeMilestone.summary}
              </p>

              <div className="pt-5 border-t hairline-dark">
                <p className="text-[11px] uppercase tracking-[0.18em] text-[#E7DED2]/70 font-semibold mb-2">
                  Historical Significance
                </p>
                <p className="text-sm sm:text-base leading-relaxed text-[#E7DED2]/90">
                  {activeMilestone.impact}
                </p>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t hairline-dark flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <p className="text-xs italic font-editorial text-[#E7DED2]/75">
                Verified Source: {activeMilestone.source}
              </p>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleStep(-1)}
                  disabled={activeIndex === 0}
                  aria-label="Previous timeline milestone"
                  className="inline-flex items-center gap-1 px-3.5 py-2 text-xs font-medium border border-[#F5F0E8]/25 text-[#F5F0E8] hover:bg-[#641E2B] disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer whitespace-nowrap"
                >
                  <ChevronLeft className="w-4 h-4" aria-hidden="true" />
                  <span>Previous</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleStep(1)}
                  disabled={activeIndex >= filteredMilestones.length - 1}
                  aria-label="Next timeline milestone"
                  className="inline-flex items-center gap-1 px-3.5 py-2 text-xs font-medium border border-[#F5F0E8]/25 text-[#F5F0E8] hover:bg-[#641E2B] disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer whitespace-nowrap"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>

          {activeMilestone.image && (
            <div className="lg:col-span-5 flex flex-col">
              <div className="editorial-photo-wrap flex-1 min-h-[280px] border border-[#F5F0E8]/15 bg-[#171717]">
                <EditorialImage
                  src={activeMilestone.image}
                  alt={activeMilestone.imageAlt || activeMilestone.title}
                  className="w-full h-full min-h-[280px]"
                  fallbackTitle={`${activeMilestone.year} — ${activeMilestone.title}`}
                />
              </div>
              <p className="mt-2.5 text-xs font-editorial italic text-[#E7DED2]/75">
                Archival visual companion · {activeMilestone.year}, {activeMilestone.location}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
