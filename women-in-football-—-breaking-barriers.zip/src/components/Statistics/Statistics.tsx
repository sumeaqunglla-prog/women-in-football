import React, { useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Info } from 'lucide-react';
import {
  DATA_SOURCES_LIST,
  DELOITTE_TOP_CLUBS_2025,
  GLOBAL_CLUB_DISTRIBUTION,
  VERIFIED_KPI_HIGHLIGHTS,
  WORLD_CUP_ATTENDANCE,
  WORLD_CUP_PRIZE_GROWTH,
} from '../../data/statisticsData';

type AttendanceMetric = 'totalAttendance' | 'avgAttendance';
type FinancialView = 'prizePool' | 'clubRevenue';

export const Statistics: React.FC = () => {
  const [attendanceMetric, setAttendanceMetric] = useState<AttendanceMetric>('totalAttendance');
  const [financialView, setFinancialView] = useState<FinancialView>('prizePool');
  const [showSources, setShowSources] = useState<boolean>(false);

  return (
    <section
      id="statistics"
      className="bg-[#F5F0E8] text-[#171717] py-20 sm:py-28 border-b hairline-cream"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-10 border-b hairline-cream">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-[0.2em] text-[#641E2B] font-semibold mb-3">
              Verified Data & Research · 1991 – 2025
            </p>
            <h2 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171717] leading-[1.06]">
              The Numbers Behind the Game
            </h2>
            <p className="mt-4 text-base text-[#171717]/80 leading-relaxed">
              Verified attendance records, global participation figures, and commercial benchmarks
              from FIFA, UEFA, and Deloitte reports—illustrating both extraordinary momentum and
              the structural gaps that remain.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowSources((prev) => !prev)}
            aria-expanded={showSources}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider border border-[#641E2B]/30 text-[#641E2B] hover:bg-[#641E2B] hover:text-[#FFFFFF] transition-colors cursor-pointer self-start lg:self-auto whitespace-nowrap shrink-0"
          >
            <Info className="w-4 h-4" aria-hidden="true" />
            <span>{showSources ? 'Hide Methodology & Sources' : 'View Methodology & Sources'}</span>
          </button>
        </div>

        {/* Collapsible Verified Sources Panel */}
        {showSources && (
          <div className="mt-6 p-6 bg-[#FFFFFF] border border-[#641E2B]/20">
            <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-4">
              Primary Institutional Sources
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {DATA_SOURCES_LIST.map((src) => (
                <div key={src.title} className="pb-4 border-b hairline-cream last:border-b-0">
                  <p className="font-editorial text-lg font-semibold text-[#171717]">{src.title}</p>
                  <p className="text-xs sm:text-sm text-[#171717]/75 mt-1 leading-relaxed">
                    {src.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* KPI Highlights Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 py-10 border-b hairline-cream">
          {VERIFIED_KPI_HIGHLIGHTS.map((kpi) => (
            <div key={kpi.label} className="bg-[#FFFFFF]/70 p-6 border border-[#641E2B]/15">
              <p className="font-data text-3xl sm:text-4xl font-medium text-[#641E2B] tabular-nums">
                {kpi.metric}
              </p>
              <p className="font-editorial text-xl font-semibold text-[#171717] mt-2 leading-snug">
                {kpi.label}
              </p>
              <p className="text-xs text-[#171717]/75 mt-2 leading-relaxed">{kpi.detail}</p>
              <p className="text-[11px] italic font-editorial text-[#641E2B] mt-3 pt-2 border-t hairline-cream">
                {kpi.source}
              </p>
            </div>
          ))}
        </div>

        {/* Chart 1: FIFA Women's World Cup Attendance Trajectory (1991–2023) */}
        <div className="py-12 border-b hairline-cream">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <p className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-1">
                Tournament Attendance · 1991 – 2023
              </p>
              <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717]">
                FIFA Women’s World Cup Stadium Growth
              </h3>
              <p className="text-sm text-[#171717]/75 mt-1">
                {attendanceMetric === 'totalAttendance'
                  ? 'Total spectators across all tournament matches (1991 China to 2023 Australia & New Zealand).'
                  : 'Average spectators per match—highlighting 1999 USA (37,944) and 2023 AUS/NZL (30,911).'}
              </p>
            </div>

            <div className="inline-flex items-center p-1 bg-[#E7DED2] border border-[#641E2B]/15 self-start">
              <button
                type="button"
                onClick={() => setAttendanceMetric('totalAttendance')}
                className={`px-3.5 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  attendanceMetric === 'totalAttendance'
                    ? 'bg-[#641E2B] text-[#FFFFFF]'
                    : 'text-[#171717] hover:text-[#641E2B]'
                }`}
              >
                Total Attendance
              </button>
              <button
                type="button"
                onClick={() => setAttendanceMetric('avgAttendance')}
                className={`px-3.5 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  attendanceMetric === 'avgAttendance'
                    ? 'bg-[#641E2B] text-[#FFFFFF]'
                    : 'text-[#171717] hover:text-[#641E2B]'
                }`}
              >
                Average per Match
              </button>
            </div>
          </div>

          <div className="bg-[#FFFFFF] p-4 sm:p-6 border border-[#641E2B]/15">
            <div className="h-[320px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={WORLD_CUP_ATTENDANCE}
                  margin={{ top: 16, right: 20, left: 10, bottom: 8 }}
                >
                  <defs>
                    <linearGradient id="burgundyArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#641E2B" stopOpacity={0.32} />
                      <stop offset="95%" stopColor="#641E2B" stopOpacity={0.03} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(23,23,23,0.08)" />
                  <XAxis
                    dataKey="year"
                    tick={{ fill: '#171717', fontSize: 12 }}
                    axisLine={{ stroke: 'rgba(100,30,43,0.2)' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: '#171717', fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v: number) =>
                      attendanceMetric === 'totalAttendance'
                        ? v >= 1000000
                          ? `${(v / 1000000).toFixed(1)}M`
                          : `${Math.round(v / 1000)}k`
                        : `${Math.round(v / 1000)}k`
                    }
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#35121B',
                      border: 'none',
                      color: '#F5F0E8',
                      fontSize: '12px',
                    }}
                    itemStyle={{ color: '#FFFFFF' }}
                    formatter={(value) => [
                      Number(value ?? 0).toLocaleString(),
                      attendanceMetric === 'totalAttendance' ? 'Total Fans' : 'Avg / Match',
                    ]}
                    labelFormatter={(label, payload) => {
                      const row = payload?.[0]?.payload;
                      return row ? `${label} · ${row.host} (${row.teams} teams, ${row.matches} matches)` : String(label);
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey={attendanceMetric}
                    stroke="#641E2B"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#burgundyArea)"
                    activeDot={{ r: 5, fill: '#35121B', stroke: '#FFFFFF', strokeWidth: 2 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="mt-4 text-xs italic font-editorial text-[#171717]/70">
              Source: FIFA Women’s World Cup Official Historical Attendance Reports (1991–2023).
            </p>
          </div>
        </div>

        {/* Two-Column Analytics Grid: Club Distribution + Commercial/Prize Growth */}
        <div className="pt-12 grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Chart 2: Global Participation & Club Infrastructure (2023) */}
          <div className="lg:col-span-5 bg-[#FFFFFF] p-6 sm:p-8 border border-[#641E2B]/15 flex flex-col justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-1">
                Infrastructure Gap · 2023
              </p>
              <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717] mb-2">
                Share of 55,622 Women’s Clubs
              </h3>
              <p className="text-sm text-[#171717]/75 leading-relaxed mb-6">
                While 16.6 million women and girls play organized football worldwide, 59% of all
                registered women’s clubs are concentrated in Europe.
              </p>

              <div className="space-y-5">
                {GLOBAL_CLUB_DISTRIBUTION.map((item, idx) => (
                  <div key={item.confederation}>
                    <div className="flex items-baseline justify-between text-sm mb-1.5">
                      <span className="font-medium text-[#171717]">{item.confederation}</span>
                      <span className="font-data font-semibold text-[#641E2B] tabular-nums">
                        {item.sharePercent}%
                      </span>
                    </div>
                    <div className="w-full h-3 bg-[#E7DED2]">
                      <div
                        className="h-full transition-all duration-500"
                        style={{
                          width: `${item.sharePercent}%`,
                          backgroundColor:
                            idx === 0 ? '#641E2B' : idx === 1 ? '#8C3B4A' : '#35121B',
                        }}
                      />
                    </div>
                    <p className="text-xs text-[#171717]/65 mt-1.5">{item.note}</p>
                  </div>
                ))}
              </div>

              {/* UEFA EURO 2022 Broadcast Verified Snapshot */}
              <div className="mt-8 pt-6 border-t hairline-cream grid grid-cols-2 gap-4">
                <div>
                  <p className="font-data text-2xl font-medium text-[#641E2B] tabular-nums">365M</p>
                  <p className="text-xs text-[#171717]/75 mt-0.5">
                    UEFA Women’s EURO 2022 live global viewers
                  </p>
                </div>
                <div>
                  <p className="font-data text-2xl font-medium text-[#641E2B] tabular-nums">54%</p>
                  <p className="text-xs text-[#171717]/75 mt-0.5">
                    Neutral fans among EURO 2022 group viewers
                  </p>
                </div>
              </div>
            </div>

            <p className="mt-6 pt-4 border-t hairline-cream text-xs italic font-editorial text-[#171717]/70">
              Source: FIFA Member Associations Survey (2023) & UEFA EURO 2022 Report.
            </p>
          </div>

          {/* Chart 3: Prize Money & Deloitte Top Club Revenues */}
          <div className="lg:col-span-7 bg-[#FFFFFF] p-6 sm:p-8 border border-[#641E2B]/15 flex flex-col justify-between">
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <p className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-1">
                    Investment & Commercial Scale
                  </p>
                  <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717]">
                    {financialView === 'prizePool'
                      ? 'World Cup Prize Pools ($ USD Millions)'
                      : 'Top Women’s Club Revenues (€ Millions, 2024/25)'}
                  </h3>
                </div>

                <div className="inline-flex items-center p-1 bg-[#E7DED2] border border-[#641E2B]/15 self-start">
                  <button
                    type="button"
                    onClick={() => setFinancialView('prizePool')}
                    className={`px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      financialView === 'prizePool'
                        ? 'bg-[#641E2B] text-[#FFFFFF]'
                        : 'text-[#171717] hover:text-[#641E2B]'
                    }`}
                  >
                    Prize Pools
                  </button>
                  <button
                    type="button"
                    onClick={() => setFinancialView('clubRevenue')}
                    className={`px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      financialView === 'clubRevenue'
                        ? 'bg-[#641E2B] text-[#FFFFFF]'
                        : 'text-[#171717] hover:text-[#641E2B]'
                    }`}
                  >
                    Club Revenues
                  </button>
                </div>
              </div>

              <p className="text-sm text-[#171717]/75 mb-6 leading-relaxed">
                {financialView === 'prizePool'
                  ? 'Women’s World Cup direct prize money rose more than sevenfold from $15M (2015) to $110M (2023), yet remains one-quarter of the $440M men’s 2022 World Cup pool.'
                  : 'In 2024/25, Deloitte’s top 15 women’s clubs generated €158M (+35% YoY), led by Arsenal (€25.6M), Chelsea (€25.4M), and FC Barcelona Femení (€22.0M).'}
              </p>

              <div className="h-[260px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  {financialView === 'prizePool' ? (
                    <BarChart
                      data={WORLD_CUP_PRIZE_GROWTH}
                      margin={{ top: 10, right: 16, left: 0, bottom: 10 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(23,23,23,0.08)" />
                      <XAxis
                        dataKey="edition"
                        tick={{ fill: '#171717', fontSize: 11 }}
                        axisLine={{ stroke: 'rgba(100,30,43,0.2)' }}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fill: '#171717', fontSize: 12 }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(v) => `$${v}M`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#35121B',
                          border: 'none',
                          color: '#F5F0E8',
                          fontSize: '12px',
                        }}
                        formatter={(value) => [`$${value}M USD`, 'Prize Pool']}
                      />
                      <Bar dataKey="prizeMoneyUSD" maxBarSize={64}>
                        {WORLD_CUP_PRIZE_GROWTH.map((entry, idx) => (
                          <Cell
                            key={entry.edition}
                            fill={idx === 3 ? '#171717' : idx === 2 ? '#641E2B' : '#9B5A65'}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  ) : (
                    <BarChart
                      data={DELOITTE_TOP_CLUBS_2025}
                      margin={{ top: 10, right: 16, left: 0, bottom: 10 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(23,23,23,0.08)" />
                      <XAxis
                        dataKey="club"
                        tick={{ fill: '#171717', fontSize: 12 }}
                        axisLine={{ stroke: 'rgba(100,30,43,0.2)' }}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fill: '#171717', fontSize: 12 }}
                        axisLine={false}
                        tickLine={false}
                        domain={[0, 30]}
                        tickFormatter={(v) => `€${v}M`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#35121B',
                          border: 'none',
                          color: '#F5F0E8',
                          fontSize: '12px',
                        }}
                        formatter={(value) => [`€${value}M`, '2024/25 Revenue']}
                      />
                      <Bar dataKey="revenueEurMillions" maxBarSize={72} fill="#641E2B" />
                    </BarChart>
                  )}
                </ResponsiveContainer>
              </div>
            </div>

            <p className="mt-6 pt-4 border-t hairline-cream text-xs italic font-editorial text-[#171717]/70">
              {financialView === 'prizePool'
                ? 'Source: FIFA Financial Reports (2015–2023). Note: 2023 total women’s commitment including club & prep funds reached $152M.'
                : 'Source: Deloitte Football Money League (2025 Edition). Top 15 clubs averaged over €10M each for the first time.'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
