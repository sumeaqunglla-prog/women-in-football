import React, { useEffect, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { LEGENDS_DATA, LegendProfile } from '../../data/legendsData';
import { EditorialImage } from '../common/EditorialImage';

interface PlayerProfilesProps {
  selectedLegend: LegendProfile | null;
  onSelectLegend: (legend: LegendProfile | null) => void;
}

export const PlayerProfiles: React.FC<PlayerProfilesProps> = ({
  selectedLegend,
  onSelectLegend,
}) => {
  const [featuredId, setFeaturedId] = useState<string>(LEGENDS_DATA[0].id);
  const featured = LEGENDS_DATA.find((p) => p.id === featuredId) ?? LEGENDS_DATA[0];
  const secondaryPlayers = LEGENDS_DATA.filter((p) => p.id !== featured.id);

  const openIndex = selectedLegend
    ? LEGENDS_DATA.findIndex((p) => p.id === selectedLegend.id)
    : -1;

  useEffect(() => {
    if (!selectedLegend) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onSelectLegend(null);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedLegend, onSelectLegend]);

  const handleCycleModal = (dir: -1 | 1) => {
    if (openIndex < 0) return;
    const nextIdx = (openIndex + dir + LEGENDS_DATA.length) % LEGENDS_DATA.length;
    onSelectLegend(LEGENDS_DATA[nextIdx]);
  };

  return (
    <section
      id="legends"
      className="bg-[#FFFFFF] text-[#171717] py-20 sm:py-28 border-b hairline-cream"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-10 border-b hairline-cream">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-[0.2em] text-[#641E2B] font-semibold mb-3">
              Editorial Portrait Gallery
            </p>
            <h2 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171717] leading-[1.06]">
              Legends of the Game
            </h2>
          </div>
          <p className="text-sm sm:text-base text-[#171717]/75 max-w-md leading-relaxed">
            Five footballers whose excellence, resilience, and public courage expanded what was
            imaginable for women on the world’s biggest stages.
          </p>
        </div>

        {/* Tier 1: Lead Editorial Feature Spread */}
        <div className="py-12 border-b hairline-cream grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          <div className="lg:col-span-5">
            <div className="editorial-photo-wrap h-full min-h-[380px] max-h-[540px] bg-[#E7DED2]">
              <EditorialImage
                src={featured.image}
                alt={featured.imageAlt}
                className="w-full h-full min-h-[380px] max-h-[540px]"
                imgClassName="w-full h-full object-cover object-top"
                fallbackTitle={featured.name}
              />
            </div>
          </div>

          <div className="lg:col-span-7 flex flex-col justify-between py-2">
            <div>
              <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-4">
                <span>Featured Portrait</span>
                <span aria-hidden="true">·</span>
                <span>{featured.country}</span>
                <span aria-hidden="true">·</span>
                <span>{featured.position}</span>
              </div>

              <h3 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171717] leading-none mb-3">
                {featured.fullName}
              </h3>

              <p className="font-editorial text-xl sm:text-2xl italic text-[#641E2B] leading-snug mb-6">
                {featured.tagline}
              </p>

              <p className="text-base leading-relaxed text-[#171717]/85 mb-6 max-w-2xl">
                {featured.fullBio}
              </p>

              {/* Verified Career Figures */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-5 border-y hairline-cream mb-6">
                {featured.stats.map((stat) => (
                  <div key={stat.label}>
                    <p className="font-data text-2xl sm:text-3xl font-medium text-[#641E2B] tabular-nums">
                      {stat.value}
                    </p>
                    <p className="text-xs text-[#171717]/70 mt-1 leading-snug">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4">
              <button
                type="button"
                onClick={() => onSelectLegend(featured)}
                className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider bg-[#641E2B] text-[#FFFFFF] hover:bg-[#35121B] transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B]"
              >
                <span>Inspect Full Dossier</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>

              <p className="text-xs italic font-editorial text-[#171717]/65">
                Source: {featured.source}
              </p>
            </div>
          </div>
        </div>

        {/* Tier 2: Asymmetrical 4-Column Magazine Roster */}
        <div className="pt-12">
          <div className="flex items-center justify-between mb-8">
            <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold">
              Select a Legend to Feature or Read Full Dossier
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {secondaryPlayers.map((player, index) => (
              <article
                key={player.id}
                className={`group flex flex-col justify-between pb-6 border-b hairline-cream ${
                  index % 2 === 1 ? 'lg:mt-8' : ''
                }`}
              >
                <div>
                  <button
                    type="button"
                    onClick={() => setFeaturedId(player.id)}
                    className="w-full text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B]"
                    aria-label={`Feature ${player.name} in lead spotlight`}
                  >
                    <div className="editorial-photo-wrap aspect-[3/4] bg-[#E7DED2] mb-4">
                      <EditorialImage
                        src={player.image}
                        alt={player.imageAlt}
                        className="w-full h-full"
                        imgClassName="w-full h-full object-cover object-top"
                        fallbackTitle={player.name}
                      />
                    </div>

                    <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-1.5">
                      <span>{player.country}</span>
                      <span aria-hidden="true">·</span>
                      <span>{player.position}</span>
                    </div>

                    <h4 className="font-editorial text-2xl font-semibold text-[#171717] group-hover:text-[#641E2B] transition-colors">
                      {player.name}
                    </h4>

                    <p className="text-sm text-[#171717]/75 leading-relaxed mt-2 line-clamp-3">
                      {player.shortBio}
                    </p>
                  </button>
                </div>

                <div className="mt-4 pt-3 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setFeaturedId(player.id)}
                    className="text-xs font-medium text-[#171717]/75 hover:text-[#641E2B] cursor-pointer whitespace-nowrap"
                  >
                    Spotlight
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectLegend(player)}
                    className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-[#641E2B] hover:text-[#35121B] cursor-pointer whitespace-nowrap"
                  >
                    <span>Dossier</span>
                    <ArrowRight className="w-3 h-3" aria-hidden="true" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>

      {/* Detailed Legend Dossier Modal */}
      {selectedLegend && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="legend-dossier-title"
          className="fixed inset-0 z-50 bg-[#171717]/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
          onClick={() => onSelectLegend(null)}
        >
          <div
            className="bg-[#F5F0E8] text-[#171717] w-full max-w-4xl max-h-[90vh] overflow-y-auto border border-[#641E2B]/25 shadow-2xl my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 z-10 bg-[#F5F0E8]/95 backdrop-blur-sm px-6 py-4 border-b hairline-cream flex items-center justify-between gap-4">
              <span className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold">
                Player Dossier · {selectedLegend.country}
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCycleModal(-1)}
                  aria-label="Previous legend"
                  className="p-2 text-[#171717] hover:bg-[#E7DED2] transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleCycleModal(1)}
                  aria-label="Next legend"
                  className="p-2 text-[#171717] hover:bg-[#E7DED2] transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onSelectLegend(null)}
                  aria-label="Close player dossier"
                  className="p-2 text-[#171717] hover:bg-[#641E2B] hover:text-[#FFFFFF] transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-10 grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
              <div className="md:col-span-5">
                <div className="aspect-[3/4] bg-[#E7DED2]">
                  <EditorialImage
                    src={selectedLegend.image}
                    alt={selectedLegend.imageAlt}
                    className="w-full h-full"
                    imgClassName="w-full h-full object-cover object-top"
                    fallbackTitle={selectedLegend.name}
                  />
                </div>
                <blockquote className="mt-5 pt-4 border-t hairline-cream font-editorial italic text-lg text-[#35121B]">
                  “{selectedLegend.quote}”
                </blockquote>
              </div>

              <div className="md:col-span-7 space-y-6">
                <div>
                  <p className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-1">
                    {selectedLegend.position} · Active {selectedLegend.era}
                  </p>
                  <h3
                    id="legend-dossier-title"
                    className="font-editorial text-4xl font-semibold text-[#171717]"
                  >
                    {selectedLegend.fullName}
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-4 py-4 border-y hairline-cream">
                  {selectedLegend.stats.map((stat) => (
                    <div key={stat.label}>
                      <p className="font-data text-2xl font-medium text-[#641E2B] tabular-nums">
                        {stat.value}
                      </p>
                      <p className="text-xs text-[#171717]/75">{stat.label}</p>
                    </div>
                  ))}
                </div>

                <div>
                  <h4 className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-2">
                    Career Narrative
                  </h4>
                  <p className="text-sm sm:text-base leading-relaxed text-[#171717]/90">
                    {selectedLegend.fullBio}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-2">
                    Impact on Women’s Football
                  </h4>
                  <p className="text-sm sm:text-base leading-relaxed text-[#171717]/90">
                    {selectedLegend.contribution}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold mb-2">
                    Major Honors & Records
                  </h4>
                  <ul className="space-y-2 text-sm text-[#171717]/90">
                    {selectedLegend.achievements.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="text-[#641E2B] font-bold" aria-hidden="true">
                          —
                        </span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <p className="text-xs italic font-editorial text-[#171717]/65 pt-4 border-t hairline-cream">
                  Source: {selectedLegend.source}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
