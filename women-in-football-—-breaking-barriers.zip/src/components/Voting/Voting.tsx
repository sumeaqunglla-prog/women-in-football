import React, { useEffect, useState } from 'react';
import { Check, RotateCcw } from 'lucide-react';
import { VOTE_OPTIONS } from '../../data/interactiveData';

const STORAGE_VOTES_KEY = 'wif_local_poll_votes_v1';
const STORAGE_USER_VOTE_KEY = 'wif_local_user_choice_v1';

type VoteCounts = Record<string, number>;

const createEmptyCounts = (): VoteCounts =>
  VOTE_OPTIONS.reduce((acc, opt) => {
    acc[opt.id] = 0;
    return acc;
  }, {} as VoteCounts);

export const Voting: React.FC = () => {
  const [votes, setVotes] = useState<VoteCounts>(createEmptyCounts);
  const [userChoice, setUserChoice] = useState<string | null>(null);

  useEffect(() => {
    try {
      const savedVotes = localStorage.getItem(STORAGE_VOTES_KEY);
      const savedChoice = localStorage.getItem(STORAGE_USER_VOTE_KEY);
      if (savedVotes) {
        const parsed = JSON.parse(savedVotes) as VoteCounts;
        setVotes({ ...createEmptyCounts(), ...parsed });
      }
      if (savedChoice) {
        setUserChoice(savedChoice);
      }
    } catch {
      // Ignore storage parsing errors
    }
  }, []);

  const persistPoll = (nextVotes: VoteCounts, nextChoice: string | null) => {
    try {
      localStorage.setItem(STORAGE_VOTES_KEY, JSON.stringify(nextVotes));
      if (nextChoice) {
        localStorage.setItem(STORAGE_USER_VOTE_KEY, nextChoice);
      } else {
        localStorage.removeItem(STORAGE_USER_VOTE_KEY);
      }
    } catch {
      // Ignore storage write errors
    }
  };

  const handleVote = (optionId: string) => {
    const nextVotes = { ...votes };
    if (userChoice && nextVotes[userChoice] > 0) {
      nextVotes[userChoice] -= 1;
    }
    nextVotes[optionId] = (nextVotes[optionId] || 0) + 1;
    setVotes(nextVotes);
    setUserChoice(optionId);
    persistPoll(nextVotes, optionId);
  };

  const handleResetDemo = () => {
    const empty = createEmptyCounts();
    setVotes(empty);
    setUserChoice(null);
    persistPoll(empty, null);
  };

  const totalVotes = Object.values(votes).reduce((sum, count) => sum + count, 0);

  return (
    <div className="bg-[#FFFFFF] border border-[#641E2B]/15 p-6 sm:p-10">
      <div className="pb-6 mb-6 border-b hairline-cream flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-2">
            Vote for Change
          </p>
          <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717]">
            What needs the most improvement in women’s football?
          </h3>
        </div>
        <p className="font-data text-xs text-[#171717]/75 tabular-nums whitespace-nowrap">
          {totalVotes} {totalVotes === 1 ? 'local vote' : 'local votes'} recorded
        </p>
      </div>

      <div className="space-y-3 mb-6">
        {VOTE_OPTIONS.map((option) => {
          const count = votes[option.id] || 0;
          const percent = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
          const isChosen = userChoice === option.id;

          return (
            <button
              key={option.id}
              type="button"
              onClick={() => handleVote(option.id)}
              className={`w-full text-left p-4 border transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B] ${
                isChosen
                  ? 'border-[#641E2B] bg-[#F5F0E8]'
                  : 'border-[#641E2B]/15 bg-[#FFFFFF] hover:bg-[#F5F0E8]/60'
              }`}
            >
              <div className="flex items-center justify-between gap-4 mb-2">
                <div className="flex items-center gap-2.5">
                  <span
                    className={`w-4 h-4 flex items-center justify-center border ${
                      isChosen
                        ? 'bg-[#641E2B] border-[#641E2B] text-[#FFFFFF]'
                        : 'border-[#641E2B]/40'
                    }`}
                    aria-hidden="true"
                  >
                    {isChosen && <Check className="w-3 h-3" />}
                  </span>
                  <span className="font-medium text-sm sm:text-base text-[#171717]">
                    {option.label}
                  </span>
                </div>

                <span className="font-data text-xs sm:text-sm font-medium text-[#641E2B] tabular-nums shrink-0">
                  {totalVotes > 0 ? `${percent}% (${count})` : 'Select'}
                </span>
              </div>

              <p className="text-xs text-[#171717]/70 mb-2.5 pl-6.5">{option.description}</p>

              {/* Percentage Bar */}
              <div className="w-full h-2 bg-[#E7DED2] overflow-hidden">
                <div
                  className="h-full bg-[#641E2B] transition-all duration-300 ease-out"
                  style={{ width: `${percent}%` }}
                />
              </div>
            </button>
          );
        })}
      </div>

      <div className="pt-4 border-t hairline-cream flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#171717]/70">
        <p>
          Demonstration Poll: Votes are stored locally in your browser via{' '}
          <code className="font-data text-[#641E2B]">localStorage</code> (no external server or
          fabricated baseline figures). You can cast or change your vote anytime.
        </p>
        {totalVotes > 0 && (
          <button
            type="button"
            onClick={handleResetDemo}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-[#641E2B] hover:text-[#35121B] cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Reset Local Poll</span>
          </button>
        )}
      </div>
    </div>
  );
};
