import React, { useState } from 'react';
import { ArrowUp, Check, Share2 } from 'lucide-react';
import { DATA_SOURCES_LIST } from '../../data/statisticsData';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [copied, setCopied] = useState(false);

  const handleCopyShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <footer className="bg-[#35121B] text-[#F5F0E8] pt-16 pb-12 border-t border-[#F5F0E8]/15">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b hairline-dark">
          {/* Branding & Editorial Mission */}
          <div className="md:col-span-4 space-y-4">
            <p className="font-editorial text-2xl font-semibold tracking-[0.12em] uppercase text-[#FFFFFF]">
              WOMEN IN FOOTBALL
            </p>
            <p className="text-sm text-[#E7DED2]/80 leading-relaxed max-w-sm">
              An interactive editorial chronicle documenting the pioneers, struggles, verified
              milestones, and future of women’s association football around the world.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleCopyShare}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium border border-[#F5F0E8]/25 text-[#F5F0E8] hover:bg-[#641E2B] transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Link Copied</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Share Editorial</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => onNavigate('home')}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium border border-[#F5F0E8]/25 text-[#F5F0E8] hover:bg-[#641E2B] transition-colors cursor-pointer"
              >
                <ArrowUp className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Back to Top</span>
              </button>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-3">
            <p className="text-xs uppercase tracking-[0.18em] text-[#E7DED2]/70 font-semibold mb-4">
              Sections
            </p>
            <ul className="space-y-2.5 text-sm">
              {[
                { id: 'home', label: 'Home' },
                { id: 'the-story', label: 'The Story (8 Chapters)' },
                { id: 'breaking-barriers', label: 'Breaking Barriers Timeline' },
                { id: 'legends', label: 'Legends of the Game' },
                { id: 'statistics', label: 'Verified Statistics' },
                { id: 'interactive-lab', label: 'Interactive Football Lab' },
                { id: 'the-future', label: 'The Next Generation' },
              ].map((link) => (
                <li key={link.id}>
                  <a
                    href={`#${link.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate(link.id);
                    }}
                    className="text-[#E7DED2]/85 hover:text-[#FFFFFF] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Verified Article & Statistical Sources */}
          <div className="md:col-span-5">
            <p className="text-xs uppercase tracking-[0.18em] text-[#E7DED2]/70 font-semibold mb-4">
              Verified Historical & Statistical Sources
            </p>
            <ul className="space-y-3 text-xs text-[#E7DED2]/80 leading-relaxed">
              {DATA_SOURCES_LIST.map((src) => (
                <li key={src.title}>
                  <span className="font-semibold text-[#FFFFFF] block">{src.title}</span>
                  <span>{src.detail}</span>
                </li>
              ))}
              <li>
                <span className="font-semibold text-[#FFFFFF] block">
                  The Football Association & National Football Museum Archives
                </span>
                <span>
                  1920 Goodison Park (53,000 spectators), 1921 FA Ban Resolution, and 1971
                  reinstatement records.
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-[#E7DED2]/65">
          <p>© 2026 Women in Football — Breaking Barriers. Editorial Digital Feature.</p>
          <p>
            All historical dates and tournament figures are cited from institutional football
            archives. Local poll and story inputs remain in browser storage.
          </p>
        </div>
      </div>
    </footer>
  );
};
