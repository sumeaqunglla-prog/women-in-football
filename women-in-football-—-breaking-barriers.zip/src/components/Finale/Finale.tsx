import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { EditorialImage } from '../common/EditorialImage';

interface FinaleProps {
  onNextChapter: () => void;
}

export const Finale: React.FC<FinaleProps> = ({ onNextChapter }) => {
  return (
    <section className="relative min-h-[75vh] w-full flex items-center bg-[#171717] text-[#FFFFFF] overflow-hidden">
      <div className="absolute inset-0">
        <EditorialImage
          src="/src/assets/images/tunnel_walkout_finale_1795104376169.jpg"
          alt="Female football players walking side by side out of a stadium tunnel toward a floodlit pitch and packed crowd"
          className="w-full h-full"
          imgClassName="w-full h-full object-cover object-center"
          fallbackTitle="The Next Chapter"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-[#171717]/90 via-[#35121B]/65 to-[#171717]/60"
          aria-hidden="true"
        />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 sm:px-8 lg:px-12 py-24 text-center">
        <p className="text-xs uppercase tracking-[0.22em] text-[#E7DED2]/85 font-semibold mb-6">
          Epilogue · Women in Football
        </p>

        <h2 className="font-editorial text-4xl sm:text-5xl md:text-6xl font-semibold leading-[1.05] text-[#FFFFFF] mb-6">
          THEY DIDN’T JUST CHANGE THE GAME. THEY CHANGED WHAT WAS POSSIBLE.
        </h2>

        <p className="text-base sm:text-lg text-[#F5F0E8]/90 max-w-2xl mx-auto leading-relaxed mb-10">
          Every sold-out stadium, every youth academy scholarship, and every girl stepping onto
          a neighborhood pitch today stands on the courage of those who refused to leave the field.
        </p>

        <button
          type="button"
          onClick={onNextChapter}
          className="inline-flex items-center gap-2.5 px-8 py-4 text-xs sm:text-sm font-semibold uppercase tracking-[0.16em] bg-[#F5F0E8] text-[#35121B] hover:bg-[#FFFFFF] transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FFFFFF]"
        >
          <span>BE PART OF THE NEXT CHAPTER</span>
          <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
        </button>
      </div>
    </section>
  );
};
