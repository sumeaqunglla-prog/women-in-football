import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { FOOTBALL_FACTS } from '../../data/interactiveData';

export const FactsDeck: React.FC = () => {
  const [activeFactIdx, setActiveFactIdx] = useState(0);
  const currentFact = FOOTBALL_FACTS[activeFactIdx];

  const handleStep = (dir: -1 | 1) => {
    setActiveFactIdx((prev) => (prev + dir + FOOTBALL_FACTS.length) % FOOTBALL_FACTS.length);
  };

  return (
    <div className="bg-[#FFFFFF] border border-[#641E2B]/15 p-6 sm:p-10">
      <div className="pb-6 mb-6 border-b hairline-cream flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-2">
            Verified Archive · Football Facts
          </p>
          <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717]">
            Surprising Facts From Women’s Football History
          </h3>
        </div>
        <span className="font-data text-xs text-[#641E2B] tabular-nums">
          Fact {String(activeFactIdx + 1).padStart(2, '0')} /{' '}
          {String(FOOTBALL_FACTS.length).padStart(2, '0')}
        </span>
      </div>

      {/* Spotlight Fact Card */}
      <div className="p-6 sm:p-8 bg-[#35121B] text-[#F5F0E8] mb-6">
        <p className="text-xs uppercase tracking-[0.18em] text-[#E7DED2]/80 font-semibold mb-3">
          {currentFact.category}
        </p>
        <h4 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#FFFFFF] mb-4">
          {currentFact.headline}
        </h4>
        <p className="text-base sm:text-lg leading-relaxed text-[#F5F0E8]/90 max-w-3xl mb-5">
          {currentFact.fact}
        </p>
        <p className="text-xs italic font-editorial text-[#E7DED2]/75 pt-4 border-t hairline-dark">
          Verified Source: {currentFact.source}
        </p>
      </div>

      {/* Controls + Quick Selector Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1.5">
          {FOOTBALL_FACTS.map((fact, idx) => (
            <button
              key={fact.id}
              type="button"
              onClick={() => setActiveFactIdx(idx)}
              aria-label={`View fact ${idx + 1}: ${fact.headline}`}
              className={`w-8 h-8 font-data text-xs transition-colors cursor-pointer ${
                idx === activeFactIdx
                  ? 'bg-[#641E2B] text-[#FFFFFF]'
                  : 'bg-[#E7DED2]/70 text-[#171717] hover:bg-[#E7DED2]'
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleStep(-1)}
            className="inline-flex items-center gap-1 px-4 py-2 text-xs font-medium border border-[#641E2B]/25 text-[#171717] hover:bg-[#E7DED2] cursor-pointer whitespace-nowrap"
          >
            <ChevronLeft className="w-4 h-4" aria-hidden="true" />
            <span>Previous</span>
          </button>
          <button
            type="button"
            onClick={() => handleStep(1)}
            className="inline-flex items-center gap-1 px-4 py-2 text-xs font-semibold bg-[#641E2B] text-[#FFFFFF] hover:bg-[#35121B] cursor-pointer whitespace-nowrap"
          >
            <span>Next Fact</span>
            <ChevronRight className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
};
