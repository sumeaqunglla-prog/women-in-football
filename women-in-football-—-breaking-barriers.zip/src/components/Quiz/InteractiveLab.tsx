import React from 'react';
import { Award, BookMarked, MessageSquarePlus, Vote } from 'lucide-react';
import { Quiz } from './Quiz';
import { FactsDeck } from './FactsDeck';
import { Voting } from '../Voting/Voting';
import { StoryForm } from '../StoryForm/StoryForm';

export type LabTab = 'quiz' | 'vote' | 'story' | 'facts';

interface InteractiveLabProps {
  activeTab: LabTab;
  onTabChange: (tab: LabTab) => void;
}

const LAB_TABS: { id: LabTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'quiz', label: 'A. Football Quiz', icon: Award },
  { id: 'vote', label: 'B. Vote for Change', icon: Vote },
  { id: 'story', label: 'C. Share Your Story', icon: MessageSquarePlus },
  { id: 'facts', label: 'D. Football Facts', icon: BookMarked },
];

export const InteractiveLab: React.FC<InteractiveLabProps> = ({ activeTab, onTabChange }) => {
  return (
    <section
      id="interactive-lab"
      className="bg-[#E7DED2] text-[#171717] py-20 sm:py-28 border-b hairline-cream"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-10 border-b hairline-cream">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-[0.2em] text-[#641E2B] font-semibold mb-3">
              Reader Participation
            </p>
            <h2 className="font-editorial text-4xl sm:text-5xl font-semibold text-[#171717] leading-[1.06]">
              The Interactive Football Lab
            </h2>
            <p className="mt-4 text-base text-[#171717]/80 leading-relaxed">
              Test your knowledge of women’s football history, vote on the priorities shaping its
              next decade, share a message for young players, and explore verified archival facts.
            </p>
          </div>
        </div>

        {/* Segmented Control Tabs */}
        <div
          role="tablist"
          aria-label="Interactive Football Lab Modules"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 py-8"
        >
          {LAB_TABS.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-3 px-5 py-4 text-left border transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B] ${
                  isSelected
                    ? 'bg-[#641E2B] border-[#641E2B] text-[#FFFFFF]'
                    : 'bg-[#F5F0E8] border-[#641E2B]/15 text-[#171717] hover:bg-[#FFFFFF]'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span className="text-xs sm:text-sm font-semibold tracking-wide whitespace-nowrap truncate">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Module Panel */}
        <div>
          {activeTab === 'quiz' && <Quiz />}
          {activeTab === 'vote' && <Voting />}
          {activeTab === 'story' && <StoryForm />}
          {activeTab === 'facts' && <FactsDeck />}
        </div>
      </div>
    </section>
  );
};
