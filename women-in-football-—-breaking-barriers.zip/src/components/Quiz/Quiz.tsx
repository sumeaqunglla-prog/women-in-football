import React, { useState } from 'react';
import { CheckCircle2, RotateCcw, XCircle } from 'lucide-react';
import { QUIZ_QUESTIONS } from '../../data/interactiveData';

export const Quiz: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [answersLog, setAnswersLog] = useState<
    { questionId: string; chosen: number; correct: number }[]
  >([]);

  const currentQ = QUIZ_QUESTIONS[currentIndex];
  const hasAnswered = selectedOption !== null;
  const isCorrect = hasAnswered && selectedOption === currentQ.correctIndex;

  const handleSelectOption = (optionIdx: number) => {
    if (hasAnswered) return;
    setSelectedOption(optionIdx);
    if (optionIdx === currentQ.correctIndex) {
      setScore((prev) => prev + 1);
    }
    setAnswersLog((prev) => [
      ...prev,
      {
        questionId: currentQ.id,
        chosen: optionIdx,
        correct: currentQ.correctIndex,
      },
    ]);
  };

  const handleNext = () => {
    if (currentIndex + 1 < QUIZ_QUESTIONS.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
    } else {
      setFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setScore(0);
    setFinished(false);
    setAnswersLog([]);
  };

  if (finished) {
    const percentage = Math.round((score / QUIZ_QUESTIONS.length) * 100);
    const verdict =
      score >= 9
        ? 'Football Historian'
        : score >= 6
          ? 'Dedicated Supporter'
          : 'Rising Challenger';

    return (
      <div className="bg-[#FFFFFF] border border-[#641E2B]/15 p-6 sm:p-10">
        <div className="pb-6 border-b hairline-cream flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-2">
              Final Quiz Results
            </p>
            <h3 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171717]">
              {verdict}: {score} of {QUIZ_QUESTIONS.length} Correct
            </h3>
          </div>
          <p className="font-data text-4xl font-medium text-[#641E2B] tabular-nums">
            {percentage}%
          </p>
        </div>

        <p className="text-sm sm:text-base text-[#171717]/80 leading-relaxed mt-6 mb-8 max-w-2xl">
          {score >= 8
            ? 'Exceptional command of women’s football history—from 1920 Goodison Park to modern World Cup and Champions League milestones.'
            : 'Thank you for testing your knowledge. Review the verified historical answers below or retake the quiz anytime.'}
        </p>

        <div className="space-y-3 mb-8 max-h-[340px] overflow-y-auto pr-2">
          {QUIZ_QUESTIONS.map((q, idx) => {
            const log = answersLog.find((a) => a.questionId === q.id);
            const passed = log?.chosen === q.correctIndex;
            return (
              <div
                key={q.id}
                className="p-4 border border-[#641E2B]/15 bg-[#F5F0E8]/60 flex items-start gap-3"
              >
                {passed ? (
                  <CheckCircle2 className="w-5 h-5 text-[#14532D] shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-5 h-5 text-[#641E2B] shrink-0 mt-0.5" />
                )}
                <div className="text-sm">
                  <p className="font-medium text-[#171717]">
                    <span className="font-data mr-1.5 text-[#641E2B]">
                      {String(idx + 1).padStart(2, '0')}.
                    </span>
                    {q.question}
                  </p>
                  <p className="text-xs text-[#171717]/75 mt-1">
                    Correct Answer: <strong className="text-[#171717]">{q.options[q.correctIndex]}</strong>
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={handleRestart}
          className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider bg-[#641E2B] text-[#FFFFFF] hover:bg-[#35121B] transition-colors cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" aria-hidden="true" />
          <span>Restart Quiz</span>
        </button>
      </div>
    );
  }

  return (
    <div className="bg-[#FFFFFF] border border-[#641E2B]/15 p-6 sm:p-10">
      {/* Progress & Score Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 mb-6 border-b hairline-cream">
        <div className="flex items-center gap-3 text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold">
          <span>
            Question {currentIndex + 1} of {QUIZ_QUESTIONS.length}
          </span>
          <span aria-hidden="true">·</span>
          <span>{currentQ.category}</span>
        </div>

        <div className="text-xs font-medium text-[#171717]/75 tabular-nums">
          Current Score: <strong className="font-data text-[#641E2B]">{score}</strong>
        </div>
      </div>

      {/* Question Prompt */}
      <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717] leading-snug mb-6 max-w-3xl">
        {currentQ.question}
      </h3>

      {/* Multiple Choice Options */}
      <div className="space-y-3 mb-6">
        {currentQ.options.map((option, idx) => {
          const isThisSelected = selectedOption === idx;
          const isThisCorrect = idx === currentQ.correctIndex;

          let stateStyle =
            'border-[#641E2B]/20 bg-[#F5F0E8]/45 text-[#171717] hover:bg-[#E7DED2]/70 hover:border-[#641E2B]/50';
          if (hasAnswered) {
            if (isThisCorrect) {
              stateStyle = 'border-[#14532D] bg-[#14532D]/10 text-[#14532D] font-semibold';
            } else if (isThisSelected) {
              stateStyle = 'border-[#641E2B] bg-[#641E2B]/10 text-[#641E2B]';
            } else {
              stateStyle = 'border-[#641E2B]/10 bg-[#F5F0E8]/25 text-[#171717]/50';
            }
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={hasAnswered}
              onClick={() => handleSelectOption(idx)}
              className={`w-full text-left p-4 border transition-colors duration-150 flex items-center justify-between gap-4 cursor-pointer disabled:cursor-default focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B] ${stateStyle}`}
            >
              <div className="flex items-center gap-3.5">
                <span className="font-data text-xs w-6 h-6 flex items-center justify-center border border-current/30 shrink-0">
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="text-sm sm:text-base">{option}</span>
              </div>

              {hasAnswered && isThisCorrect && (
                <span className="inline-flex items-center gap-1 text-xs font-semibold shrink-0">
                  <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                  Correct
                </span>
              )}
              {hasAnswered && isThisSelected && !isThisCorrect && (
                <span className="inline-flex items-center gap-1 text-xs font-semibold shrink-0">
                  <XCircle className="w-4 h-4" aria-hidden="true" />
                  Incorrect
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Immediate Feedback Drawer */}
      {hasAnswered && (
        <div className="p-5 bg-[#F5F0E8] border border-[#641E2B]/20 mb-6">
          <p className="text-xs uppercase tracking-[0.16em] font-semibold mb-1.5 text-[#641E2B]">
            {isCorrect ? 'Verified Correct' : 'Historical Note'}
          </p>
          <p className="text-sm leading-relaxed text-[#171717]/90">{currentQ.explanation}</p>
          <p className="text-xs italic font-editorial text-[#171717]/65 mt-2">
            Source: {currentQ.source}
          </p>
        </div>
      )}

      {/* Navigation Controls */}
      <div className="flex items-center justify-between pt-4 border-t hairline-cream">
        <button
          type="button"
          onClick={handleRestart}
          className="text-xs font-medium text-[#171717]/65 hover:text-[#641E2B] cursor-pointer"
        >
          Reset Progress
        </button>

        <button
          type="button"
          disabled={!hasAnswered}
          onClick={handleNext}
          className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#641E2B] text-[#FFFFFF] hover:bg-[#35121B] disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
        >
          {currentIndex + 1 === QUIZ_QUESTIONS.length ? 'View Final Results' : 'Next Question'}
        </button>
      </div>
    </div>
  );
};
