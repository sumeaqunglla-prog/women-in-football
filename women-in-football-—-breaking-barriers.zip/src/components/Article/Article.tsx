import React, { useEffect, useState } from 'react';
import { ArrowUpRight, BookOpen } from 'lucide-react';
import { ARTICLE_CHAPTERS, ARTICLE_METADATA } from '../../data/articleData';
import { LEGENDS_DATA, LegendProfile } from '../../data/legendsData';
import { EditorialImage } from '../common/EditorialImage';

interface ArticleProps {
  onSelectLegend: (legend: LegendProfile) => void;
}

export const Article: React.FC<ArticleProps> = ({ onSelectLegend }) => {
  const [activeChapterId, setActiveChapterId] = useState<string>(ARTICLE_CHAPTERS[0].id);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible.length > 0) {
          setActiveChapterId(visible[0].target.id);
        }
      },
      { rootMargin: '-20% 0px -60% 0px', threshold: [0.15, 0.4] }
    );

    ARTICLE_CHAPTERS.forEach((ch) => {
      const el = document.getElementById(ch.id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const scrollToChapter = (chapterId: string) => {
    setActiveChapterId(chapterId);
    const el = document.getElementById(chapterId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section
      id="the-story"
      className="bg-[#F5F0E8] text-[#171717] py-20 sm:py-28 border-b hairline-cream"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Editorial Masthead */}
        <header className="max-w-4xl pb-12 border-b hairline-cream">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-4">
            <span>{ARTICLE_METADATA.sectionLabel}</span>
            <span aria-hidden="true">·</span>
            <span>{ARTICLE_METADATA.edition}</span>
            <span aria-hidden="true">·</span>
            <span>{ARTICLE_METADATA.readingTime}</span>
          </div>

          <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.04] tracking-[-0.015em] text-[#171717] mb-6">
            {ARTICLE_METADATA.title}
          </h2>

          <p className="font-editorial text-xl sm:text-2xl italic text-[#35121B]/85 leading-relaxed max-w-3xl">
            {ARTICLE_METADATA.subtitle}
          </p>
        </header>

        {/* Mobile / Tablet Quick Chapter Selector */}
        <div className="lg:hidden py-6 border-b hairline-cream overflow-x-auto">
          <div className="flex items-center gap-2 min-w-max">
            {ARTICLE_CHAPTERS.map((ch) => (
              <button
                key={ch.id}
                type="button"
                onClick={() => scrollToChapter(ch.id)}
                className={`px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeChapterId === ch.id
                    ? 'bg-[#641E2B] text-[#FFFFFF]'
                    : 'bg-[#E7DED2]/70 text-[#171717] hover:bg-[#E7DED2]'
                }`}
              >
                <span className="font-data mr-1.5">{ch.number}.</span>
                <span>{ch.title.split('–')[0].trim()}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Broadsheet Grid: Sticky Chapter Rail + Long-Form Chapters */}
        <div className="pt-12 lg:grid lg:grid-cols-12 lg:gap-12 items-start">
          {/* Left Sticky Chapter Index */}
          <aside className="hidden lg:block lg:col-span-3 sticky top-24">
            <div className="pb-4 mb-4 border-b hairline-cream flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-[#641E2B] font-semibold">
              <BookOpen className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Article Chapters</span>
            </div>

            <nav aria-label="Article Chapters" className="space-y-1">
              {ARTICLE_CHAPTERS.map((ch) => {
                const isSelected = activeChapterId === ch.id;
                return (
                  <button
                    key={ch.id}
                    type="button"
                    onClick={() => scrollToChapter(ch.id)}
                    className={`w-full text-left py-2.5 px-3 transition-colors duration-150 cursor-pointer block border-b hairline-cream/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B] ${
                      isSelected
                        ? 'bg-[#E7DED2] text-[#35121B] font-semibold'
                        : 'text-[#171717]/75 hover:text-[#641E2B] hover:bg-[#E7DED2]/40'
                    }`}
                  >
                    <span className="font-data text-[11px] text-[#641E2B] block mb-0.5">
                      Chapter {ch.number}
                    </span>
                    <span className="text-[13px] leading-snug block">{ch.title}</span>
                  </button>
                );
              })}
            </nav>
          </aside>

          {/* Main Long-Form Editorial Stream */}
          <div className="lg:col-span-9 space-y-20">
            {ARTICLE_CHAPTERS.map((chapter) => (
              <article
                key={chapter.id}
                id={chapter.id}
                onMouseEnter={() => setActiveChapterId(chapter.id)}
                className="scroll-mt-24 pb-16 border-b hairline-cream last:border-b-0 last:pb-0"
              >
                {/* Chapter Header */}
                <div className="mb-8">
                  <div className="flex items-center gap-3 text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-3">
                    <span className="font-data">{chapter.number}.</span>
                    <span aria-hidden="true">/</span>
                    <span>{chapter.kicker}</span>
                  </div>
                  <h3 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#171717] leading-[1.12] mb-4">
                    {chapter.title}
                  </h3>
                  <p className="text-base sm:text-lg text-[#35121B]/85 font-medium max-w-2xl leading-relaxed">
                    {chapter.summary}
                  </p>
                </div>

                {/* 70/30 Asymmetric Canvas: Narrative Prose + Margin Note */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 xl:gap-10 items-start">
                  <div className="xl:col-span-8 space-y-6 max-w-prose">
                    {chapter.paragraphs.map((para, idx) => (
                      <p
                        key={idx}
                        className={`text-[16px] sm:text-[17px] leading-[1.78] text-[#171717]/90 ${
                          idx === 0 ? 'editorial-dropcap' : ''
                        }`}
                      >
                        {para}
                      </p>
                    ))}
                  </div>

                  {/* Margin Archival Note */}
                  <aside className="xl:col-span-4 bg-[#E7DED2]/60 p-6 border border-[#641E2B]/15">
                    <p className="text-[11px] uppercase tracking-[0.18em] text-[#641E2B] font-semibold mb-2">
                      {chapter.marginNote.label}
                    </p>
                    <p className="text-sm leading-relaxed text-[#171717]/90 mb-3">
                      {chapter.marginNote.text}
                    </p>
                    <p className="text-xs italic font-editorial text-[#35121B]/80 pt-3 border-t hairline-cream">
                      Source: {chapter.marginNote.source}
                    </p>
                  </aside>
                </div>

                {/* Optional Pull Quote (Hairline top/bottom, no left border bar) */}
                {chapter.pullQuote && (
                  <blockquote className="my-10 py-8 border-y hairline-cream max-w-3xl">
                    <p className="font-editorial text-2xl sm:text-3xl italic text-[#35121B] leading-snug mb-3">
                      “{chapter.pullQuote.quote}”
                    </p>
                    <footer className="text-xs uppercase tracking-[0.16em] text-[#641E2B] font-medium">
                      {chapter.pullQuote.attribution}
                    </footer>
                  </blockquote>
                )}

                {/* Optional Editorial Photograph */}
                {chapter.figure && (
                  <figure className="mt-10">
                    <div className="editorial-photo-wrap overflow-hidden bg-[#E7DED2]">
                      <EditorialImage
                        src={chapter.figure.src}
                        alt={chapter.figure.alt}
                        className="w-full aspect-[16/10]"
                        fallbackTitle={chapter.figure.figureLabel}
                      />
                    </div>
                    <figcaption className="mt-3 text-xs sm:text-sm font-editorial italic text-[#35121B]/80 flex flex-wrap gap-2">
                      <span className="font-semibold not-italic text-[#641E2B]">
                        {chapter.figure.figureLabel} —
                      </span>
                      <span>{chapter.figure.caption}</span>
                    </figcaption>
                  </figure>
                )}

                {/* Chapter 04 Integrated Legends Editorial Profiles */}
                {chapter.id === 'chapter-04' && (
                  <div className="mt-10 pt-8 border-t hairline-cream space-y-6">
                    <p className="text-xs uppercase tracking-[0.18em] text-[#641E2B] font-semibold">
                      Featured Editorial Profiles · Five Transformative Careers
                    </p>
                    <div className="divide-y divide-[#641E2B]/15 border-y border-[#641E2B]/15 bg-[#FFFFFF]/55">
                      {LEGENDS_DATA.map((player) => (
                        <div
                          key={player.id}
                          className="p-5 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-center"
                        >
                          <div className="md:col-span-3">
                            <div className="editorial-photo-wrap overflow-hidden aspect-[3/4] max-w-[180px] bg-[#E7DED2]">
                              <EditorialImage
                                src={player.image}
                                alt={player.imageAlt}
                                className="w-full h-full"
                                fallbackTitle={player.name}
                              />
                            </div>
                          </div>

                          <div className="md:col-span-9 space-y-3">
                            <div className="flex flex-wrap items-baseline justify-between gap-2">
                              <div>
                                <h4 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#171717]">
                                  {player.fullName}
                                </h4>
                                <p className="text-xs uppercase tracking-[0.15em] text-[#641E2B] font-medium mt-0.5">
                                  {player.country} · {player.position} · {player.era}
                                </p>
                              </div>
                              <button
                                type="button"
                                onClick={() => onSelectLegend(player)}
                                className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#641E2B] hover:text-[#35121B] border-b border-[#641E2B]/40 pb-0.5 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#641E2B]"
                              >
                                <span>Full Profile</span>
                                <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                              </button>
                            </div>

                            <p className="text-sm leading-relaxed text-[#171717]/85">
                              {player.shortBio} {player.contribution}
                            </p>

                            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 pt-2 text-xs text-[#35121B]/90">
                              {player.achievements.slice(0, 2).map((ach, i) => (
                                <li key={i} className="flex items-start gap-2">
                                  <span className="text-[#641E2B] font-bold" aria-hidden="true">
                                    —
                                  </span>
                                  <span>{ach}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
