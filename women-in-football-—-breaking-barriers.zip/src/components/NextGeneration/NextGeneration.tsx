import React from 'react';
import { ArrowRight } from 'lucide-react';
import { EditorialImage } from '../common/EditorialImage';

interface NextGenerationProps {
  onShareMessage: () => void;
}

const NEXT_GEN_PILLARS = [
  {
    number: '01',
    title: 'Equal Opportunities',
    description:
      'Every girl who asks to play should find an organized team waiting—free from cultural stigma or schoolyard exclusion.',
  },
  {
    number: '02',
    title: 'Grassroots Football',
    description:
      'Community clubs and school leagues form the bedrock of lifelong participation, confidence, and local talent discovery.',
  },
  {
    number: '03',
    title: 'Youth Academies',
    description:
      'Structured technical, tactical, and sports-science development pathways give young players the same foundation boys receive.',
  },
  {
    number: '04',
    title: 'Supportive Coaches',
    description:
      'Educated, encouraging coaches—and visible women on the touchline—teach resilience, leadership, and tactical ambition.',
  },
  {
    number: '05',
    title: 'Accessible Training Facilities',
    description:
      'Safe evening floodlights, proper changing rooms, quality grass pitches, and boots built for female biomechanics keep girls in the game.',
  },
];

export const NextGeneration: React.FC<NextGenerationProps> = ({ onShareMessage }) => {
  return (
    <section
      id="the-future"
      className="bg-[#FFFFFF] text-[#171717] py-20 sm:py-28 border-b hairline-cream"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Two-Column Visual + Editorial Lead */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch pb-14 border-b hairline-cream">
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#641E2B] font-semibold mb-4">
                Women in Football · The Next Generation
              </p>

              <h2 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#171717] leading-[1.02] mb-6">
                THE NEXT GENERATION IS ALREADY ON THE PITCH.
              </h2>

              <p className="text-base sm:text-lg text-[#171717]/85 leading-relaxed max-w-xl mb-6">
                Today, 16.6 million women and girls play organized football worldwide. Whether a
                ten-year-old girl stays in the sport through adolescence depends on five everyday
                commitments—not on distant stadium records alone.
              </p>
            </div>

            <div className="pt-4">
              <button
                type="button"
                onClick={onShareMessage}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider bg-[#641E2B] text-[#FFFFFF] hover:bg-[#35121B] transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>Write a Message for Young Players</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="editorial-photo-wrap h-full min-h-[300px] bg-[#E7DED2]">
              <EditorialImage
                src="/src/assets/images/youth_girls_pitch_1795104377532.jpg"
                alt="Diverse young girls playing football together on a sunlit community pitch with a coach watching from the sideline"
                className="w-full h-full min-h-[300px]"
                fallbackTitle="The Next Generation"
              />
            </div>
          </div>
        </div>

        {/* Five Foundations Matrix */}
        <div className="pt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
          {NEXT_GEN_PILLARS.map((pillar) => (
            <div key={pillar.number} className="pt-4 border-t border-[#641E2B]/25">
              <span className="font-data text-xs text-[#641E2B] font-medium block mb-2">
                {pillar.number}.
              </span>
              <h3 className="font-editorial text-2xl font-semibold text-[#171717] mb-2.5">
                {pillar.title}
              </h3>
              <p className="text-sm leading-relaxed text-[#171717]/75">{pillar.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
