/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { EditorialHomePage } from './pages/EditorialHomePage';

export default function App() {
  return <EditorialHomePage />;
}
