export type TimelineEra = 'all' | 'pioneers' | 'ban' | 'breakthrough' | 'modern';

export interface TimelineMilestone {
  id: string;
  year: string;
  title: string;
  era: Exclude<TimelineEra, 'all'>;
  eraLabel: string;
  location: string;
  summary: string;
  impact: string;
  source: string;
  image?: string;
  imageAlt?: string;
}

export const TIMELINE_ERAS: { id: TimelineEra; label: string }[] = [
  { id: 'all', label: 'All Eras' },
  { id: 'pioneers', label: 'Early Pioneers' },
  { id: 'ban', label: 'The Ban Years' },
  { id: 'breakthrough', label: 'Global Breakthrough' },
  { id: 'modern', label: 'Modern Stadium Era' },
];

export const TIMELINE_MILESTONES: TimelineMilestone[] = [
  {
    id: 'm-1895',
    year: '1895',
    title: "British Ladies' Football Club Debut",
    era: 'pioneers',
    eraLabel: 'Early Pioneers',
    location: 'London, England',
    summary:
      "Founded by activist Nettie Honeyball, the British Ladies' Football Club staged a landmark North vs. South fixture at Crouch End before roughly 10,000 spectators.",
    impact:
      'Established the first widely publicized organized women’s football club structure in Britain, challenging Victorian restrictions on women’s athletic attire and public life.',
    source: 'National Football Museum Archives / British Newspaper Archive (1895)',
  },
  {
    id: 'm-1920',
    year: '1920',
    title: '53,000 Pack Goodison Park',
    era: 'pioneers',
    eraLabel: 'Early Pioneers',
    location: 'Liverpool, England',
    summary:
      'On Boxing Day (December 26, 1920), Preston’s Dick, Kerr Ladies defeated St. Helens Ladies 4–0 in front of 53,000 fans inside Goodison Park, with over 10,000 turned away outside.',
    impact:
      'Proved that women’s club matches could command elite men’s-level stadium crowds while raising major funds for war relief charities.',
    source: 'The FA & National Football Museum Historical Match Records',
    image: '/src/assets/images/vintage_pioneers_pitch_1795104374681.jpg',
    imageAlt: 'Archival style portrait of early 1920s women football pioneers on a grass pitch',
  },
  {
    id: 'm-1921',
    year: '1921',
    title: 'The English FA Ban',
    era: 'ban',
    eraLabel: 'The Ban Years',
    location: 'London, England',
    summary:
      'On December 5, 1921, the Football Association banned women from playing on any FA-affiliated club grounds, claiming football was “quite unsuitable for females.”',
    impact:
      'Drove women’s football off established pitches and out of mainstream media for fifty years, inspiring similar restrictions in other nations.',
    source: 'FA Consultative Committee Resolution (December 5, 1921)',
  },
  {
    id: 'm-1941',
    year: '1941',
    title: 'Brazil Prohibits Women’s Football',
    era: 'ban',
    eraLabel: 'The Ban Years',
    location: 'Rio de Janeiro, Brazil',
    summary:
      'Brazil’s National Sports Council enacted Decree-Law 3199, legally barring women from football and several other sports until the ban was finally lifted in 1979.',
    impact:
      'Delayed the formal development of women’s leagues across South America’s most celebrated football nation for nearly four decades.',
    source: 'Brazilian Federal Decree-Law No. 3199 (1941–1979)',
  },
  {
    id: 'm-1971',
    year: '1971',
    title: 'Azteca Crowd & FA Ban Lifted',
    era: 'ban',
    eraLabel: 'The Ban Years',
    location: 'Mexico City & London',
    summary:
      'An unofficial Women’s World Cup final at Estadio Azteca drew an estimated 110,000 spectators in September 1971. Three months later, following UEFA pressure and the WFA’s organizing, the English FA lifted its 50-year ban.',
    impact:
      'Marked the decisive end of official prohibition in Europe and paved the way for recognized national federations and international fixtures.',
    source: 'The FA Archives (1971) & FIFA Museum Documentation',
  },
  {
    id: 'm-1972',
    year: '1972',
    title: 'Title IX Enacted in the United States',
    era: 'breakthrough',
    eraLabel: 'Global Breakthrough',
    location: 'Washington, D.C., USA',
    summary:
      'Title IX prohibited sex-based discrimination in federally funded schools and universities, transforming collegiate women’s sports funding and scholarship access.',
    impact:
      'Created a deep collegiate athletic pipeline that fueled the rise of the U.S. Women’s National Team and global collegiate recruitment.',
    source: 'U.S. Education Amendments Act of 1972 (Title IX)',
  },
  {
    id: 'm-1991',
    year: '1991',
    title: 'Inaugural FIFA Women’s World Cup',
    era: 'breakthrough',
    eraLabel: 'Global Breakthrough',
    location: 'Guangdong, China',
    summary:
      'FIFA staged the first official Women’s World Championship across China with 12 teams and 515,000 total spectators, won by the United States over Norway.',
    impact:
      'Legitimized women’s football within FIFA’s global tournament calendar and sparked investment across confederations.',
    source: 'FIFA Technical Report — 1st Women’s World Championship (1991)',
  },
  {
    id: 'm-1999',
    year: '1999',
    title: 'Rose Bowl Final Draws 90,185',
    era: 'breakthrough',
    eraLabel: 'Global Breakthrough',
    location: 'Pasadena, California, USA',
    summary:
      'The 1999 FIFA Women’s World Cup final between the United States and China filled the Rose Bowl with 90,185 fans and averaged 37,944 spectators across the whole tournament.',
    impact:
      'Remains the highest single-tournament average attendance in Women’s World Cup history and catalyzed the launch of professional women’s leagues.',
    source: 'FIFA Women’s World Cup USA 1999 Official Report',
    image: '/src/assets/images/portrait_classic_forward_1795104376068.jpg',
    imageAlt: '1990s US women’s national team forward on a sunlit stadium pitch',
  },
  {
    id: 'm-2018',
    year: '2018',
    title: 'First Women’s Ballon d’Or Awarded',
    era: 'modern',
    eraLabel: 'Modern Stadium Era',
    location: 'Paris, France',
    summary:
      'France Football introduced the Ballon d’Or Féminin in 2018—sixty-two years after the men’s award—with Norwegian striker Ada Hegerberg named the inaugural winner.',
    impact:
      'Corrected a six-decade omission in world football’s most prestigious individual honor.',
    source: 'France Football Ballon d’Or Féminin Ceremony (December 2018)',
  },
  {
    id: 'm-2022',
    year: '2022',
    title: 'Camp Nou 91,648 & EURO Wembley 87,192',
    era: 'modern',
    eraLabel: 'Modern Stadium Era',
    location: 'Barcelona & London',
    summary:
      'FC Barcelona Femení drew 91,648 fans at Camp Nou in the Champions League (April 2022). In July, England defeated Germany before 87,192 at Wembley to win UEFA Women’s EURO 2022.',
    impact:
      'Set all-time global club attendance and all-time European Championship final attendance records, reaching 365M live viewers for EURO 2022.',
    source: 'UEFA Women’s Champions League & EURO 2022 Official Reports',
    image: '/src/assets/images/modern_camp_nou_1795104375609.jpg',
    imageAlt: 'Packed European football stadium at twilight during a women’s Champions League night',
  },
  {
    id: 'm-2023',
    year: '2023',
    title: 'Record 1.98M Fans at Expanded World Cup',
    era: 'modern',
    eraLabel: 'Modern Stadium Era',
    location: 'Australia & New Zealand',
    summary:
      'The first 32-team FIFA Women’s World Cup recorded 1,978,274 total spectators, ~2 billion global audience reach, and a $152 million overall financial commitment including direct player payouts.',
    impact:
      'Demonstrated worldwide commercial scalability across the Southern Hemisphere and pushed club licensing and guaranteed player pay onto the global agenda.',
    source: 'FIFA Global Engagement & Audience Report (2023)',
    image: '/src/assets/images/hero_stadium_players_1795104375233.jpg',
    imageAlt: 'Female footballers celebrating in front of a roaring stadium crowd',
  },
];
