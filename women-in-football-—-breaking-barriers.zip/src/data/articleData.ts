export interface ArticleFigure {
  src: string;
  alt: string;
  figureLabel: string;
  caption: string;
}

export interface ArticleMarginNote {
  label: string;
  text: string;
  source: string;
}

export interface ArticleChapter {
  id: string;
  number: string;
  title: string;
  kicker: string;
  summary: string;
  paragraphs: string[];
  pullQuote?: {
    quote: string;
    attribution: string;
  };
  figure?: ArticleFigure;
  marginNote: ArticleMarginNote;
}

export const ARTICLE_METADATA = {
  title: 'More Than a Game: The Women Who Changed Football Forever',
  subtitle:
    "From fighting for the right to play to filling the world's biggest stadiums, discover the women who challenged expectations and transformed the beautiful game.",
  sectionLabel: 'Investigative Feature',
  edition: 'Archival & Modern Chronicle',
  readingTime: '14 min read',
  updatedYear: '2026 Edition',
};

export const ARTICLE_CHAPTERS: ArticleChapter[] = [
  {
    id: 'chapter-01',
    number: '01',
    title: 'The Beginning – A History Worth Telling',
    kicker: 'Origins & Early Crowds (1881–1920)',
    summary:
      'Long before modern broadcast deals, women packed industrial-era grounds across Britain—until gate receipts and cultural anxieties forced the sport underground.',
    paragraphs: [
      'Women’s association football did not begin in the late twentieth century; it took root alongside the earliest codification of the modern game. In May 1881, pioneering women’s sides representing Scotland and England met at Easter Road in Edinburgh before thousands of curious onlookers, facing hostility from sections of the press and spectators that forced subsequent fixtures behind closed gates. Fourteen years later, in 1895, activist Nettie Honeyball founded the British Ladies’ Football Club in London, staging a North versus South exhibition before roughly 10,000 spectators at Crouch End.',
      'The first true golden era arrived during the First World War, when women entered munitions factories across Britain and formed works teams to raise relief funds for wounded soldiers and bereaved families. Foremost among them were the Dick, Kerr Ladies of Preston, founded in 1917 at the Dick, Kerr & Co. tramway and munitions plant. Playing fast, skilful football in striped jerseys, they toured Britain and France, raising tens of thousands of pounds for hospitals and war charities.',
      'On Boxing Day, December 26, 1920, Dick, Kerr Ladies faced St. Helens Ladies at Goodison Park in Liverpool. According to historical match records preserved by the National Football Museum, 53,000 spectators filled the stadium while an estimated 10,000 to 15,000 more were turned away outside the gates. Women’s football was not a novelty; it was already a major spectator sport.',
    ],
    pullQuote: {
      quote:
        'Fifty-three thousand supporters packed Goodison Park on Boxing Day 1920—proving a century ago that audiences showed up whenever women were given the pitch.',
      attribution: 'National Football Museum Archival Record · Goodison Park, 1920',
    },
    figure: {
      src: '/src/assets/images/vintage_pioneers_pitch_1795104374681.jpg',
      alt: 'Early twentieth-century female football players standing together on a misty grass pitch in striped jerseys and leather boots',
      figureLabel: 'Fig. 1',
      caption:
        'Editorial reconstruction inspired by early twentieth-century works teams such as Dick, Kerr Ladies, who drew tens of thousands of spectators between 1917 and 1921.',
    },
    marginNote: {
      label: 'Archival Fact',
      text: 'Between 1917 and 1921, Dick, Kerr Ladies played 67 matches—winning 59, drawing 5, and losing only 3—while raising substantial sums for post-war charitable funds.',
      source: 'The Football Association & National Football Museum Archives',
    },
  },
  {
    id: 'chapter-02',
    number: '02',
    title: 'The Fight for the Right to Play',
    kicker: 'Prohibition & Erasure (1921–1971)',
    summary:
      'For fifty years, national federations across Europe and South America banned women from affiliated stadiums, attempting to legislate an entire gender off the pitch.',
    paragraphs: [
      'That explosive popularity alarmed the male football establishment. On December 5, 1921, the English Football Association Consultative Committee passed a resolution banning women’s matches from the grounds of all FA-affiliated clubs. Its stated justification—that “the game of football is quite unsuitable for females and ought not to be encouraged”—was accompanied by unsubstantiated medical claims and administrative anxieties over charity revenues bypassing FA oversight.',
      'The 1921 decree did not stop in England. Similar restrictions rippled across the football world for decades. In Brazil, Decree-Law 3199 of 1941 prohibited women from playing sports deemed “incompatible with the conditions of their nature,” a formal ban on women’s football that remained in force until 1979. In West Germany, the German Football Association (DFB) banned women’s teams from member clubs between 1955 and 1970, citing fears over physical strain and maternal health.',
      'Stripped of stadiums, changing rooms, referees, and press coverage, women refused to vanish. Players organized matches in public parks, factory yards, and independent leagues. In 1970 and 1971, two unofficial Women’s World Cups staged in Italy and Mexico without FIFA sanction demonstrated enduring public appetite: the 1971 final between Denmark and Mexico drew an estimated 110,000 spectators to Estadio Azteca in Mexico City, even while institutional federations still withheld official recognition.',
    ],
    marginNote: {
      label: 'Half-Century Ban',
      text: 'The English FA ban lasted 50 years (1921–1971); Brazil’s state decree lasted 38 years (1941–1979). Both disrupted generations of coaching, youth pathways, and archival records.',
      source: 'FA Historical Resolution (1921) · Brazilian Decree-Law 3199 (1941)',
    },
  },
  {
    id: 'chapter-03',
    number: '03',
    title: 'Breaking Barriers',
    kicker: 'Reinstatement & Institutional Breakthrough (1969–1999)',
    summary:
      'Grassroots organizers, legislative equality, and the inaugural 1991 World Cup transformed excluded amateurs into international pioneers.',
    paragraphs: [
      'Change came because players built their own institutions first. In 1969, forty-four clubs came together to form the Women’s Football Association (WFA) in England, creating organized domestic structures and pressuring UEFA to recognize the women’s game. In 1971, UEFA recommended that member associations integrate women’s football, prompting the English FA to finally lift its fifty-year ban in December 1971. Across the Atlantic, the passage of Title IX in the United States in 1972 barred sex discrimination in federally funded education, unlocking university scholarships and athletic training for millions of girls.',
      'Momentum accelerated through the 1980s as national teams formed across Scandinavia, Asia, and North America. Yet FIFA still lacked an official global championship for women. Following a successful 1988 pilot invitation tournament in Guangdong, China, FIFA staged the inaugural Women’s World Championship in 1991—later formally titled the FIFA Women’s World Cup.',
      'Twelve nations competed across China in 1991, with matches initially lasting 80 minutes before shifting to 90 minutes in 1995. When the United States hosted the third edition in 1999, 90,185 spectators filled the Rose Bowl in Pasadena for the final against China, setting a then-record for a women’s sporting event and broadcasting an unmistakable message to sports executives worldwide.',
    ],
    pullQuote: {
      quote:
        'The 1999 Rose Bowl final before 90,185 fans did not invent women’s football—it forced television networks and sponsors to acknowledge what players had long proven.',
      attribution: 'Editorial Analysis · Historical Milestone 1999',
    },
    marginNote: {
      label: 'Turning Point',
      text: 'The 1999 FIFA Women’s World Cup averaged 37,944 spectators per match across 32 games—a single-tournament average record that still stands today.',
      source: 'FIFA Tournament Attendance Records (1991–2023)',
    },
  },
  {
    id: 'chapter-04',
    number: '04',
    title: 'The Legends Who Changed Everything',
    kicker: 'Architects of Excellence',
    summary:
      'Five transformative footballers—Marta, Alexia Putellas, Megan Rapinoe, Ada Hegerberg, and Mia Hamm—redefined technical brilliance and demanded structural equality.',
    paragraphs: [
      'Every era of progress in women’s football was carried on the shoulders of players who excelled under uneven conditions while widening the path for those behind them. From Mia Hamm’s relentless 1990s trailblazing and Marta’s unmatched artistry across six FIFA World Cups, to Ada Hegerberg’s historic stand for structural respect in Norway, Megan Rapinoe’s fearless advocacy for equal pay, and Alexia Putellas’s orchestral command before 91,648 supporters at Camp Nou, these athletes elevated both tactical standards and public conscience.',
      'Explore their editorial profiles in the Legends gallery below to inspect verified career records, landmark honors, and the pivotal roles each played in reshaping the global game.',
    ],
    marginNote: {
      label: 'Global Icons',
      text: 'Together, these five players span three continents, 11 major FIFA/Ballon d’Or World Player honors, and multiple World Cup and Champions League dynasties.',
      source: 'FIFA, France Football Ballon d’Or & UEFA Official Records',
    },
  },
  {
    id: 'chapter-05',
    number: '05',
    title: 'The Modern Era',
    kicker: 'The Stadium & Commercial Inflection (2019–Present)',
    summary:
      'Shattered attendance ceilings, dedicated broadcast deals, and record-breaking revenues have turned women’s football into one of global sport’s fastest-growing sectors.',
    paragraphs: [
      'Over the last decade, women’s football crossed from sporadic tournament curiosity into sustained club and international permanence. The 2019 FIFA Women’s World Cup in France reached 1.12 billion unique viewers globally across broadcast and digital platforms, establishing an unprecedented commercial baseline. Three years later, Europe experienced a seismic club and international surge.',
      'On March 30, 2022, 91,553 fans watched FC Barcelona Femení defeat Real Madrid in a UEFA Women’s Champions League quarter-final at Camp Nou—only for Barcelona to break their own world record weeks later with 91,648 spectators against Wolfsburg. That summer, UEFA Women’s EURO 2022 in England drew 574,875 fans overall, culminating in 87,192 supporters at Wembley Stadium, the largest crowd for any men’s or women’s European Championship final in history.',
      'In 2023, the expanded 32-team FIFA Women’s World Cup in Australia and New Zealand sold 1,978,274 tickets—averaging nearly 31,000 per match—and reached an estimated 2 billion global audience. Crucially, fan engagement deepened: Deloitte’s 2025 Football Money League reported that the top 15 revenue-generating women’s clubs reached €158 million in cumulative revenue in 2024/25, a 35 percent year-on-year surge led by Arsenal (€25.6M), Chelsea (€25.4M), and FC Barcelona (€22.0M).',
    ],
    figure: {
      src: '/src/assets/images/modern_camp_nou_1795104375609.jpg',
      alt: 'Massive floodlit European football stadium packed to capacity during a modern women’s Champions League match',
      figureLabel: 'Fig. 2',
      caption:
        'Modern European nights have rewritten expectations: Camp Nou welcomed 91,648 spectators in April 2022, while Wembley hosted 87,192 for the EURO 2022 final.',
    },
    marginNote: {
      label: 'Broadcast Depth',
      text: 'In UEFA’s 2022 post-tournament report, 54% of group-stage viewers were neutral sports followers—evidence that women’s football now commands mainstream audiences.',
      source: 'UEFA Women’s EURO 2022 Post-Tournament Report',
    },
  },
  {
    id: 'chapter-06',
    number: '06',
    title: 'The Challenges That Remain',
    kicker: 'Structural Gaps & Unfinished Business',
    summary:
      'Record crowds at the summit coexist with stark disparities in prize pools, medical research, club infrastructure, and grassroots access worldwide.',
    paragraphs: [
      'Headline stadium sellouts tell only part of the story. Beneath the elite tier, structural inequities persist across investment, compensation, medical care, and opportunity. Even after FIFA tripled tournament disbursements to $152 million (including $110 million in direct prize money) for the 2023 Women’s World Cup, that allocation remained a quarter of the $440 million prize pool awarded at the 2022 men’s World Cup.',
      'Disparities are equally visible in day-to-day infrastructure. According to FIFA’s 2023 Member Associations Survey, 59 percent of all women’s football clubs globally are concentrated in Europe (UEFA) and 22 percent in Asia (AFC), leaving vast regions of Africa, South America, and Oceania fighting for basic leagues, travel stipends, and professional contracts. Many top-flight women’s teams still train on secondary pitches or artificial turf while negotiating basic maternity protections and minimum wages.',
      'Media coverage and sports science also lag behind. Historically, sports media allocated only a fraction of its airtime to women’s competitions outside major tournament windows, creating a self-fulfilling myth of low interest. Meanwhile, female footballers suffer anterior cruciate ligament (ACL) injuries at rates roughly two to six times higher than male players, driven in part by boots engineered on male foot lasts, uneven pitch quality, and decades of underfunded female-specific physiology research.',
    ],
    marginNote: {
      label: 'Global Disparity',
      text: 'Out of 55,622 registered women’s clubs recorded in FIFA’s 2023 survey, 59% are located in UEFA—highlighting urgent need for investment across other confederations.',
      source: 'FIFA Women’s Football Member Associations Survey (2023)',
    },
  },
  {
    id: 'chapter-07',
    number: '07',
    title: 'The Future Belongs to Everyone',
    kicker: 'Building Sustainable Ecosystems',
    summary:
      'Mandatory club licensing, growing coaching pathways, and 16.6 million organized players worldwide signal a permanent structural transformation.',
    paragraphs: [
      'The next phase of women’s football is not about one-off charity exhibitions; it is about permanent professional architecture. Globally, 16.6 million women and girls now play organized football—an increase of nearly 24 percent between 2019 and 2023 according to FIFA’s global survey. Turning that participation wave into lasting careers requires binding club licensing rules, independent league governance, and dedicated youth academies.',
      'Crucially, representation off the pitch must keep pace with progress on it. Initiatives such as FIFA’s Coach Education Scholarship and Mentorship Programmes aim to address the shortage of women holding elite pro coaching licenses and sporting director positions. Simultaneously, dedicated broadcast slots, stand-alone commercial partnerships—rather than bundled sponsorship add-ons—and equitable prize structures are proving that women’s football is a sound, high-growth investment.',
    ],
    marginNote: {
      label: '16.6 Million Strong',
      text: 'Organized female participation climbed by ~24% between 2019 and 2023, reaching 16.6 million players across more than 200 member associations.',
      source: 'FIFA Member Associations Survey Report (2023)',
    },
  },
  {
    id: 'chapter-08',
    number: '08',
    title: 'Conclusion – The Game Is Bigger Than Barriers',
    kicker: 'Epilogue',
    summary:
      'From banned factory pitches to roaring global arenas, every barrier broken by one generation becomes the baseline of possibility for the next.',
    paragraphs: [
      'Trace the arc from Preston’s munitions pitches in 1917, through five decades of official erasure, to the 91,648 voices echoing around Camp Nou and the millions tuning in across every continent, and one truth emerges clearly: women’s football never lacked talent, passion, or an audience. It lacked permission, visibility, and sustained investment.',
      'Today, a young girl lacing up her boots in São Paulo, Oslo, Tokyo, Nairobi, or Birmingham steps onto a pitch shaped by generations of persistence. The work ahead—closing pay gaps, expanding grassroots access, funding female sports science, and guaranteeing safe professional standards—remains real and urgent. Yet history has already delivered its verdict: whenever barriers are lowered, the game grows richer for everyone who loves football.',
    ],
    pullQuote: {
      quote:
        'Women’s football never lacked talent or an audience. It lacked access—and whenever those gates have opened, the world has shown up.',
      attribution: 'Women in Football · Closing Editorial',
    },
    marginNote: {
      label: 'Continuing Legacy',
      text: 'Explore the verified timelines, player dossiers, data charts, and interactive community lab below to examine the story in detail.',
      source: 'Editorial Archive',
    },
  },
];
