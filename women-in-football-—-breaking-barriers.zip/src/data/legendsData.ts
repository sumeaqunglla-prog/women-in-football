export interface LegendProfile {
  id: string;
  name: string;
  fullName: string;
  country: string;
  position: string;
  era: string;
  image: string;
  imageAlt: string;
  tagline: string;
  shortBio: string;
  fullBio: string;
  contribution: string;
  quote: string;
  stats: {
    label: string;
    value: string;
  }[];
  achievements: string[];
  source: string;
}

export const LEGENDS_DATA: LegendProfile[] = [
  {
    id: 'marta',
    name: 'Marta',
    fullName: 'Marta Vieira da Silva',
    country: 'Brazil',
    position: 'Forward / Attacking Midfielder',
    era: '2002 – Present',
    image: '/src/assets/images/portrait_brazil_ten_1795104376781.jpg',
    imageAlt: 'Editorial sports portrait of Brazilian number 10 forward poised with a football under stadium lights',
    tagline: 'Six-time FIFA World Player of the Year and the all-time top scorer in World Cup history.',
    shortBio:
      'Born in Dois Riachos, Alagoas, Marta played barefoot in local street games before becoming the standard of brilliance in global women’s football.',
    fullBio:
      'Growing up in rural northeastern Brazil shortly after the country’s decades-long ban on women’s football ended, Marta overcame intense local prejudice to earn a professional contract at Vasco da Gama at age 14. Over a glittering two-decade career across Brazil, Sweden (Umeå IK), and the United States (Orlando Pride), she combined close-control dribbling, vision, and lethal finishing like few players in football history.',
    contribution:
      'Marta transformed South American women’s football visibility, became the first footballer—male or female—to score in five consecutive World Cups (2003–2019), and used global award stages to urge nations to invest in girls’ grassroots infrastructure.',
    quote:
      'Cry at the beginning so you can smile at the end. Women’s football depends on you to survive—value it.',
    stats: [
      { label: 'FIFA World Player Awards', value: '6' },
      { label: 'World Cup Goals (All-Time Record)', value: '17' },
      { label: 'International Goals (Brazil)', value: '122' },
      { label: 'Olympic Silver Medals', value: '3' },
    ],
    achievements: [
      '6× FIFA World Player of the Year / The Best FIFA Women’s Player (2006–2010, 2018)',
      'All-time FIFA Women’s World Cup leading scorer (17 goals)',
      '3× Olympic Silver Medalist (2004, 2008, 2024) & 3× Copa América Femenina champion',
      'UEFA Women’s Cup winner with Umeå IK (2004)',
    ],
    source: 'FIFA Official Player Records & Confederação Brasileira de Futebol',
  },
  {
    id: 'alexia-putellas',
    name: 'Alexia Putellas',
    fullName: 'Alexia Putellas Segura',
    country: 'Spain',
    position: 'Central Midfielder',
    era: '2010 – Present',
    image: '/src/assets/images/portrait_spain_midfield_1795104376009.jpg',
    imageAlt: 'Editorial portrait of Spanish midfield captain in deep burgundy and navy stripes standing in a stadium tunnel',
    tagline: 'Two-time Ballon d’Or Féminin winner and the heartbeat of Barcelona’s Camp Nou era.',
    shortBio:
      'From Mollet del Vallès to FC Barcelona Femení captaincy, Putellas turned positional intelligence and left-footed precision into packed-stadium spectacle.',
    fullBio:
      'Alexia Putellas joined FC Barcelona’s senior side in 2012, growing alongside the club’s transition from semi-professional status into Europe’s dominant tactical powerhouse. As captain, she led Barcelona to their first UEFA Women’s Champions League title in 2021 and became the club’s all-time leading female scorer while capturing consecutive Ballon d’Or Féminin trophies in 2021 and 2022.',
    contribution:
      'Putellas became the face of Europe’s modern stadium era—scoring before 91,553 and 91,648 fans at Camp Nou in 2022 and helping propel Spain to their maiden FIFA Women’s World Cup triumph in 2023.',
    quote:
      'When 91,000 people fill Camp Nou to watch women play football, nothing in this sport can ever go backwards.',
    stats: [
      { label: 'Ballon d’Or Féminin', value: '2' },
      { label: 'FIFA Best Player Awards', value: '2' },
      { label: 'UWCL Titles', value: '3' },
      { label: 'World Cup Winner', value: '2023' },
    ],
    achievements: [
      'Back-to-back Ballon d’Or Féminin winner (2021, 2022)',
      '2× The Best FIFA Women’s Player (2021, 2022)',
      '2023 FIFA Women’s World Cup Champion with Spain',
      '3× UEFA Women’s Champions League Champion with FC Barcelona Femení',
    ],
    source: 'UEFA, France Football & FC Barcelona Official Records',
  },
  {
    id: 'megan-rapinoe',
    name: 'Megan Rapinoe',
    fullName: 'Megan Anna Rapinoe',
    country: 'United States',
    position: 'Winger',
    era: '2006 – 2023',
    image: '/src/assets/images/portrait_usa_winger_1795104376136.jpg',
    imageAlt: 'Editorial documentary portrait of American platinum-blonde winger in white and navy national kit on a floodlit pitch',
    tagline: '2019 World Cup Golden Boot & Golden Ball winner who reshaped athlete advocacy for equal pay.',
    shortBio:
      'A dead-ball specialist and fearless big-match performer with 203 USWNT caps, Rapinoe paired championship dominance with systemic reform.',
    fullBio:
      'Emerging from Redding, California to earn 203 caps and 63 goals for the United States, Megan Rapinoe delivered some of the most decisive tournament performances of the modern era—including her pinpoint cross to Abby Wambach in 2011 and six goals at the 2019 World Cup in France, where she swept the Golden Boot, Golden Ball, and Ballon d’Or Féminin.',
    contribution:
      'Beyond the touchline, Rapinoe was a central voice in the USWNT’s landmark equal pay campaign, culminating in the historic 2022 collective bargaining agreement equalizing World Cup prize distributions and working conditions.',
    quote:
      'We have to love this game enough to demand that it treats every player fairly, from the stadium pitch to the grassroots.',
    stats: [
      { label: 'International Caps (USA)', value: '203' },
      { label: 'International Goals', value: '63' },
      { label: 'World Cup Titles', value: '2' },
      { label: 'Ballon d’Or Féminin', value: '2019' },
    ],
    achievements: [
      '2× FIFA Women’s World Cup Champion (2015, 2019)',
      '2019 World Cup Golden Boot & Golden Ball; 2019 Ballon d’Or Féminin',
      '2012 Olympic Gold Medalist (London)',
      '2022 Presidential Medal of Freedom recipient for athletic leadership & equality advocacy',
    ],
    source: 'U.S. Soccer Official Records & FIFA Archives',
  },
  {
    id: 'ada-hegerberg',
    name: 'Ada Hegerberg',
    fullName: 'Ada Martine Stolsmo Hegerberg',
    country: 'Norway',
    position: 'Striker',
    era: '2011 – Present',
    image: '/src/assets/images/portrait_norway_striker_1795104376196.jpg',
    imageAlt: 'Editorial sports portrait of Scandinavian striker with blonde ponytail in white and crimson kit on a European pitch',
    tagline: 'Inaugural Ballon d’Or Féminin winner and all-time top goalscorer in the UEFA Women’s Champions League.',
    shortBio:
      'An unstoppable penalty-box finisher for Olympique Lyonnais, Hegerberg also risked her international prime to demand fair federation standards.',
    fullBio:
      'Signed by Olympique Lyonnais as a teenager, Ada Hegerberg became the defining European club striker of her generation—scoring a record 15 goals in a single Champions League season and overtaking every mark as the competition’s all-time top scorer. In 2018, she became the first woman in history to lift the Ballon d’Or Féminin.',
    contribution:
      'In 2017, Hegerberg stepped away from Norway’s national team for five years to protest unequal investment and preparation standards for women’s football—returning in 2022 only after structural reforms were enacted.',
    quote:
      'Young girls around the world: please believe in yourselves. Your ambitions belong on the biggest stages.',
    stats: [
      { label: 'UWCL Titles (Lyon)', value: '6' },
      { label: 'UWCL All-Time Goals', value: '64+' },
      { label: 'Ballon d’Or Féminin', value: '2018' },
      { label: 'Single-Season UWCL Record', value: '15' },
    ],
    achievements: [
      'Inaugural Ballon d’Or Féminin winner (2018)',
      'All-time UEFA Women’s Champions League top scorer (64+ goals)',
      '6× UEFA Women’s Champions League Champion with Olympique Lyonnais',
      'UEFA Best Women’s Player in Europe (2016)',
    ],
    source: 'UEFA Official Statistics & France Football Archives',
  },
  {
    id: 'mia-hamm',
    name: 'Mia Hamm',
    fullName: 'Mariel Margaret Hamm',
    country: 'United States',
    position: 'Forward',
    era: '1987 – 2004',
    image: '/src/assets/images/portrait_classic_forward_1795104376068.jpg',
    imageAlt: 'Archival 1990s film portrait of American female football forward in classic navy and red jersey on sunlit grass pitch',
    tagline: 'The 1990s trailblazer who turned women’s football into a household global phenomenon.',
    shortBio:
      'Debuting for the USWNT at just 15 years old, Mia Hamm scored 158 international goals and inspired an entire generation worldwide.',
    fullBio:
      'When Mia Hamm won her first senior cap in 1987, the FIFA Women’s World Cup did not yet exist. Over 17 years and 276 international appearances, she amassed 158 goals—at the time the all-time international scoring record across both men’s and women’s football—and won two World Cups (1991, 1999) and two Olympic gold medals (1996, 2004).',
    contribution:
      'As the defining figure of the 1999 World Cup and the first-ever FIFA Women’s World Player of the Year (2001, 2002), Hamm proved that female footballers could command global cultural admiration and commercial sponsorship.',
    quote:
      'Celebrate what you have accomplished, but raise the bar a little higher each time you succeed.',
    stats: [
      { label: 'International Caps (USA)', value: '276' },
      { label: 'International Goals', value: '158' },
      { label: 'International Assists', value: '144' },
      { label: 'World Cup & Olympic Golds', value: '4' },
    ],
    achievements: [
      '2× FIFA Women’s World Cup Champion (1991, 1999)',
      '2× Olympic Gold Medalist (1996, 2004)',
      'Inaugural 2× FIFA Women’s World Player of the Year (2001, 2002)',
      '4× NCAA National Champion at North Carolina; National Soccer Hall of Fame inductee',
    ],
    source: 'U.S. Soccer Hall of Fame & FIFA Historical Archives',
  },
];
