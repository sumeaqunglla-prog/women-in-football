export interface QuizQuestion {
  id: string;
  category: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  source: string;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    category: 'Early History',
    question:
      'In December 1920, how many spectators packed Goodison Park to watch Dick, Kerr Ladies play St. Helens Ladies?',
    options: ['12,500', '28,000', '53,000', '74,000'],
    correctIndex: 2,
    explanation:
      'On Boxing Day 1920, 53,000 spectators filled Goodison Park in Liverpool, with an estimated 10,000–15,000 more turned away outside.',
    source: 'National Football Museum Archives (1920)',
  },
  {
    id: 'q2',
    category: 'Barriers & Bans',
    question:
      'For how long did the English Football Association ban women’s teams from playing on FA-affiliated club grounds?',
    options: ['15 years (1921–1936)', '30 years (1921–1951)', '50 years (1921–1971)', '65 years (1921–1986)'],
    correctIndex: 2,
    explanation:
      'Passed on December 5, 1921, the FA’s ban lasted fifty years until December 1971, following grassroots organizing by the Women’s Football Association and UEFA guidance.',
    source: 'The Football Association Historical Archives',
  },
  {
    id: 'q3',
    category: 'World Cup History',
    question:
      'Which nation hosted and won the inaugural official FIFA Women’s World Cup?',
    options: [
      'Hosted in China (1991), won by the United States',
      'Hosted in Sweden (1995), won by Norway',
      'Hosted in the USA (1991), won by Germany',
      'Hosted in Japan (1991), won by China',
    ],
    correctIndex: 0,
    explanation:
      'China hosted the inaugural 12-team tournament in November 1991, and the United States defeated Norway 2–1 in the final in Guangzhou.',
    source: 'FIFA Technical Report (1991)',
  },
  {
    id: 'q4',
    category: 'Legends',
    question:
      'Which footballer holds the all-time scoring record in FIFA Women’s World Cup history with 17 goals across five tournaments?',
    options: ['Mia Hamm', 'Birgit Prinz', 'Marta Vieira da Silva', 'Christine Sinclair'],
    correctIndex: 2,
    explanation:
      'Brazilian icon Marta has scored 17 goals across FIFA Women’s World Cups and became the first player—male or female—to score in five different World Cups.',
    source: 'FIFA Official Tournament Records',
  },
  {
    id: 'q5',
    category: 'Modern Milestones',
    question:
      'Who won the inaugural Ballon d’Or Féminin when France Football introduced the women’s award in 2018?',
    options: ['Alexia Putellas', 'Ada Hegerberg', 'Megan Rapinoe', 'Sam Kerr'],
    correctIndex: 1,
    explanation:
      'Norwegian and Olympique Lyonnais striker Ada Hegerberg was crowned the first-ever Ballon d’Or Féminin winner in December 2018.',
    source: 'France Football Ballon d’Or Archives (2018)',
  },
  {
    id: 'q6',
    category: 'Stadium Records',
    question:
      'What global women’s club match attendance record was set at Camp Nou during FC Barcelona Femení’s 2022 Champions League run?',
    options: ['60,739 spectators', '75,210 spectators', '87,192 spectators', '91,648 spectators'],
    correctIndex: 3,
    explanation:
      'Barcelona drew 91,553 fans against Real Madrid in March 2022 and broke their own world record weeks later with 91,648 fans against Wolfsburg.',
    source: 'UEFA Women’s Champions League Official Attendance (2022)',
  },
  {
    id: 'q7',
    category: 'European Championship',
    question:
      'At UEFA Women’s EURO 2022, 87,192 fans attended the Wembley final—making it:',
    options: [
      'The largest crowd ever for any men’s or women’s European Championship match',
      'The third-largest women’s final in England',
      'A record only for domestic English cup finals',
      'Smaller than the 2017 EURO final in the Netherlands',
    ],
    correctIndex: 0,
    explanation:
      'The 87,192 crowd for England vs. Germany surpassed every previous men’s and women’s EURO final attendance record.',
    source: 'UEFA & Guinness World Records (2022)',
  },
  {
    id: 'q8',
    category: 'Global Participation',
    question:
      'According to FIFA’s 2023 Member Associations Survey, how many women and girls play organized football worldwide?',
    options: ['4.8 million', '9.2 million', '16.6 million', '32.0 million'],
    correctIndex: 2,
    explanation:
      'FIFA recorded 16.6 million women and girls playing organized football globally in 2023, an increase of nearly 24% compared with the 2019 survey.',
    source: 'FIFA Member Associations Survey Report (2023)',
  },
  {
    id: 'q9',
    category: 'Pioneers',
    question:
      'Which 1990s forward retired with 158 international goals—then the all-time international record across both men’s and women’s football—and won the first two FIFA Women’s World Player awards?',
    options: ['Kristine Lilly', 'Mia Hamm', 'Brandi Chastain', 'Abby Wambach'],
    correctIndex: 1,
    explanation:
      'Mia Hamm scored 158 goals in 276 matches for the USA and won the inaugural FIFA Women’s World Player of the Year honors in 2001 and 2002.',
    source: 'U.S. Soccer Hall of Fame & FIFA Archives',
  },
  {
    id: 'q10',
    category: 'World Cup 2023',
    question:
      'How many total spectators attended the 64 matches of the 2023 FIFA Women’s World Cup in Australia and New Zealand?',
    options: ['845,761', '1,095,118', '1,353,486', '1,978,274'],
    correctIndex: 3,
    explanation:
      'The expanded 32-team tournament drew 1,978,274 total spectators across Australia and New Zealand, averaging 30,911 per match.',
    source: 'FIFA Global Engagement & Audience Report (2023)',
  },
];

export interface VoteOption {
  id: string;
  label: string;
  description: string;
}

export const VOTE_OPTIONS: VoteOption[] = [
  {
    id: 'equal-investment',
    label: 'Equal investment',
    description: 'Equitable prize pools, club budgets, and dedicated long-term sponsorship.',
  },
  {
    id: 'media-coverage',
    label: 'More media coverage',
    description: 'Consistent prime-time broadcast windows and year-round journalism.',
  },
  {
    id: 'training-facilities',
    label: 'Better training facilities',
    description: 'Natural grass pitches, medical science, and dedicated recovery centers.',
  },
  {
    id: 'professional-opportunities',
    label: 'More professional opportunities',
    description: 'Full-time contracts, club licensing, and coaching pathways globally.',
  },
  {
    id: 'greater-recognition',
    label: 'Greater recognition',
    description: 'Celebrating women’s football history, legends, and cultural impact equally.',
  },
];

export interface FootballFact {
  id: string;
  category: string;
  headline: string;
  fact: string;
  source: string;
}

export const FOOTBALL_FACTS: FootballFact[] = [
  {
    id: 'f1',
    category: 'History',
    headline: '110,000 Fans Before FIFA Recognition',
    fact: 'In 1971—twenty years before the first official FIFA Women’s World Cup—an unofficial Women’s World Cup final in Mexico City drew an estimated 110,000 spectators to Estadio Azteca.',
    source: 'FIFA Museum & Historical Press Archives (1971)',
  },
  {
    id: 'f2',
    category: 'Tournament Rules',
    headline: '80-Minute Matches in 1991',
    fact: 'During the inaugural 1991 FIFA Women’s World Cup in China, matches were scheduled for 80 minutes (two 40-minute halves) before FIFA standardized 90-minute matches for women in 1995.',
    source: 'FIFA Women’s World Cup 1991 Technical Report',
  },
  {
    id: 'f3',
    category: 'Audience Shift',
    headline: '54% Neutral Followers at EURO 2022',
    fact: 'UEFA’s post-tournament analysis of Women’s EURO 2022 showed that 54% of group-stage viewers were neutral sports followers, proving mainstream appeal beyond core club supporters.',
    source: 'UEFA Women’s EURO 2022 Report',
  },
  {
    id: 'f4',
    category: 'Commercial Growth',
    headline: 'Top 15 Clubs Surpass €158M Revenue',
    fact: 'According to the 2025 Deloitte Football Money League, the top 15 revenue-generating women’s clubs earned €158 million combined in 2024/25—a 35% year-on-year rise.',
    source: 'Deloitte Football Money League (2025)',
  },
  {
    id: 'f5',
    category: 'World Cup Scoring',
    headline: 'Five Consecutive World Cups',
    fact: 'Brazil’s Marta became the first player in football history—men’s or women’s—to score at five separate FIFA World Cup tournaments (2003, 2007, 2011, 2015, and 2019).',
    source: 'Guinness World Records & FIFA (2019)',
  },
  {
    id: 'f6',
    category: 'Global Clubs',
    headline: '55,622 Women’s Clubs Worldwide',
    fact: 'FIFA’s 2023 survey counted 55,622 women’s football clubs globally, yet 59% are concentrated inside Europe (UEFA), illustrating huge room for growth across other continents.',
    source: 'FIFA Member Associations Survey (2023)',
  },
  {
    id: 'f7',
    category: 'Individual Honors',
    headline: 'A 62-Year Wait for the Ballon d’Or',
    fact: 'While the men’s Ballon d’Or began in 1956, the Ballon d’Or Féminin was not established until 2018—when Ada Hegerberg became its inaugural recipient.',
    source: 'France Football (2018)',
  },
  {
    id: 'f8',
    category: 'Viewer Retention',
    headline: '532 Million Watched 20+ Minutes',
    fact: 'At the 2023 FIFA Women’s World Cup, 532.22 million linear TV viewers watched 20 minutes or more of match coverage—a 57.1% retention rate among those tuning in.',
    source: 'FIFA Global Engagement & Audience Report (2023)',
  },
];
