export interface WorldCupAttendancePoint {
  year: string;
  host: string;
  teams: number;
  matches: number;
  totalAttendance: number;
  avgAttendance: number;
}

export const WORLD_CUP_ATTENDANCE: WorldCupAttendancePoint[] = [
  { year: '1991', host: 'China', teams: 12, matches: 26, totalAttendance: 515000, avgAttendance: 19808 },
  { year: '1995', host: 'Sweden', teams: 12, matches: 26, totalAttendance: 112294, avgAttendance: 4319 },
  { year: '1999', host: 'USA', teams: 16, matches: 32, totalAttendance: 1214215, avgAttendance: 37944 },
  { year: '2003', host: 'USA', teams: 16, matches: 32, totalAttendance: 656789, avgAttendance: 20525 },
  { year: '2007', host: 'China', teams: 16, matches: 32, totalAttendance: 1176955, avgAttendance: 36780 },
  { year: '2011', host: 'Germany', teams: 16, matches: 32, totalAttendance: 845761, avgAttendance: 26430 },
  { year: '2015', host: 'Canada', teams: 24, matches: 52, totalAttendance: 1353486, avgAttendance: 26029 },
  { year: '2019', host: 'France', teams: 24, matches: 52, totalAttendance: 1095118, avgAttendance: 21060 },
  { year: '2023', host: 'AUS / NZL', teams: 32, matches: 64, totalAttendance: 1978274, avgAttendance: 30911 },
];

export interface ClubDistributionPoint {
  confederation: string;
  sharePercent: number;
  note: string;
}

export const GLOBAL_CLUB_DISTRIBUTION: ClubDistributionPoint[] = [
  {
    confederation: 'UEFA (Europe)',
    sharePercent: 59,
    note: 'Hosts 59% of all 55,622 global women’s clubs & 73% of youth competitions',
  },
  {
    confederation: 'AFC (Asia)',
    sharePercent: 22,
    note: 'Second-largest club base worldwide at 22%',
  },
  {
    confederation: 'CONCACAF, CONMEBOL, CAF & OFC',
    sharePercent: 19,
    note: 'Combined 19% share across the Americas, Africa, and Oceania',
  },
];

export interface PrizePoolPoint {
  edition: string;
  prizeMoneyUSD: number;
  note: string;
}

export const WORLD_CUP_PRIZE_GROWTH: PrizePoolPoint[] = [
  { edition: '2015 Women (Canada)', prizeMoneyUSD: 15, note: '$15M total prize pool' },
  { edition: '2019 Women (France)', prizeMoneyUSD: 30, note: '$30M prize pool (~$50M total disbursement)' },
  { edition: '2023 Women (AUS/NZL)', prizeMoneyUSD: 110, note: '$110M direct prize money ($152M total commitment)' },
  { edition: '2022 Men Benchmark (Qatar)', prizeMoneyUSD: 440, note: '$440M men’s prize pool (benchmark showing remaining gap)' },
];

export interface ClubRevenuePoint {
  club: string;
  revenueEurMillions: number;
  league: string;
}

export const DELOITTE_TOP_CLUBS_2025: ClubRevenuePoint[] = [
  { club: 'Arsenal Women', revenueEurMillions: 25.6, league: 'WSL (England)' },
  { club: 'Chelsea Women', revenueEurMillions: 25.4, league: 'WSL (England)' },
  { club: 'FC Barcelona Femení', revenueEurMillions: 22.0, league: 'Liga F (Spain)' },
];

export interface VerifiedStatHighlight {
  metric: string;
  label: string;
  detail: string;
  source: string;
}

export const VERIFIED_KPI_HIGHLIGHTS: VerifiedStatHighlight[] = [
  {
    metric: '16.6M',
    label: 'Organized Female Players Globally',
    detail: 'Up ~24% from 2019 across 200+ surveyed FIFA member associations.',
    source: 'FIFA Member Associations Survey (2023)',
  },
  {
    metric: '1,978,274',
    label: '2023 World Cup Total Attendance',
    detail: 'All-time tournament record across 64 matches in Australia & New Zealand.',
    source: 'FIFA Tournament Report (2023)',
  },
  {
    metric: '€158M',
    label: 'Top 15 Women’s Clubs Revenue',
    detail: '35% year-on-year commercial & matchday growth in 2024/25.',
    source: 'Deloitte Football Money League (2025)',
  },
  {
    metric: '91,648',
    label: 'World Record Club Crowd',
    detail: 'FC Barcelona Femení vs. Wolfsburg at Camp Nou, April 22, 2022.',
    source: 'UEFA Official Match Report (2022)',
  },
];

export const DATA_SOURCES_LIST = [
  {
    title: 'FIFA Women’s World Cup Historical & 2023 Reports (1991–2023)',
    detail: 'Official match attendance, global broadcast audience (~2B reach, 57.1% 20+ min linear TV retention), and $110M / $152M prize allocations.',
  },
  {
    title: 'FIFA "Women’s Football: Member Associations Survey Report" (2023)',
    detail: '16.6 million organized players (+24% vs. 2019), 55,622 global women’s clubs, and confederation distribution (59% UEFA, 22% AFC).',
  },
  {
    title: 'UEFA Women’s EURO 2022 Post-Tournament Report',
    detail: '574,875 total attendance, 87,192 Wembley final crowd, 365M live global viewers, and 54% neutral fan engagement.',
  },
  {
    title: 'Deloitte Football Money League (2025 Edition)',
    detail: '€158M cumulative revenue for the top 15 women’s clubs (+35% YoY), averaging over €10M per club for the first time.',
  },
];
