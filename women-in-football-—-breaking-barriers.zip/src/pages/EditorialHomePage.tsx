import React, { useEffect, useState } from 'react';
import { LegendProfile } from '../data/legendsData';
import { Navbar } from '../components/Navbar/Navbar';
import { Hero } from '../components/Hero/Hero';
import { Article } from '../components/Article/Article';
import { Timeline } from '../components/Timeline/Timeline';
import { PlayerProfiles } from '../components/PlayerProfiles/PlayerProfiles';
import { Statistics } from '../components/Statistics/Statistics';
import { InteractiveLab, LabTab } from '../components/Quiz/InteractiveLab';
import { NextGeneration } from '../components/NextGeneration/NextGeneration';
import { Finale } from '../components/Finale/Finale';
import { Footer } from '../components/Footer/Footer';

const OBSERVED_SECTIONS = [
  'home',
  'the-story',
  'breaking-barriers',
  'legends',
  'statistics',
  'interactive-lab',
  'the-future',
];

export const EditorialHomePage: React.FC = () => {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [selectedLegend, setSelectedLegend] = useState<LegendProfile | null>(null);
  const [labTab, setLabTab] = useState<LabTab>('quiz');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible.length > 0) {
          const id = visible[0].target.id;
          // Map interactive-lab to statistics/the-future or keep nav clean
          setActiveSection(id === 'interactive-lab' ? 'the-future' : id);
        }
      },
      {
        rootMargin: '-25% 0px -55% 0px',
        threshold: [0.1, 0.3, 0.6],
      }
    );

    OBSERVED_SECTIONS.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const navigateTo = (sectionId: string) => {
    const target = document.getElementById(sectionId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const openStorySubmission = () => {
    setLabTab('story');
    navigateTo('interactive-lab');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F0E8] text-[#171717]">
      <Navbar activeSection={activeSection} onNavigate={navigateTo} />

      <main className="flex-1">
        <Hero
          onExploreStory={() => navigateTo('the-story')}
          onDiscoverLegacy={() => navigateTo('legends')}
        />

        <Article onSelectLegend={(legend) => setSelectedLegend(legend)} />

        <Timeline />

        <PlayerProfiles
          selectedLegend={selectedLegend}
          onSelectLegend={(legend) => setSelectedLegend(legend)}
        />

        <Statistics />

        <InteractiveLab activeTab={labTab} onTabChange={setLabTab} />

        <NextGeneration onShareMessage={openStorySubmission} />

        <Finale onNextChapter={() => navigateTo('interactive-lab')} />
      </main>

      <Footer onNavigate={navigateTo} />
    </div>
  );
};
